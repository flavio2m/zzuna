import React from 'react';
import { Plus, Check, Trash, FolderOpen, Download, Filter, Calendar, Search } from 'lucide-react';
import { Categoria } from '../types';

interface TopbarProps {
  currentMonth: number; // 1-12
  currentYear: number;
  onMonthYearChange: (month: number, year: number) => void;
  statusFilter: 'TODAS' | 'PENDENTES' | 'CONSOLIDADOS';
  onStatusFilterChange: (filter: 'TODAS' | 'PENDENTES' | 'CONSOLIDADOS') => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCount: number;
  onBatchConsolidate: () => void;
  onBatchDelete: () => void;
  onBatchChangeCategory: (catId: string) => void;
  categoriasList: Categoria[];
  onOpenAddDialog: () => void;
  onOpenExportView: () => void;
}

export default function Topbar({
  currentMonth,
  currentYear,
  onMonthYearChange,
  statusFilter,
  onStatusFilterChange,
  searchQuery,
  onSearchChange,
  selectedCount,
  onBatchConsolidate,
  onBatchDelete,
  onBatchChangeCategory,
  categoriasList,
  onOpenAddDialog,
  onOpenExportView
}: TopbarProps) {
  // Simple arrays of available months and years for dropdown selection
  const meses = [
    { value: 1, label: 'Janeiro' },
    { value: 2, label: 'Fevereiro' },
    { value: 3, label: 'Março' },
    { value: 4, label: 'Abril' },
    { value: 5, label: 'Maio' },
    { value: 6, label: 'Junho' },
    { value: 7, label: 'Julho' },
    { value: 8, label: 'Agosto' },
    { value: 9, label: 'Setembro' },
    { value: 10, label: 'Outubro' },
    { value: 11, label: 'Novembro' },
    { value: 12, label: 'Dezembro' }
  ];

  const anos = [2025, 2026, 2027];

  // Filter only subcategories to assign in bulk
  const subCategorias = categoriasList.filter(c => c.parentId !== null && c.ativo);

  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans flex-shrink-0 select-none">
      {/* Filtros de Mês/Ano e Transações */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Dropdown Mês/Ano */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 focus-within:border-emerald-500 hover:border-slate-300 transition-colors">
          <Calendar size={14} className="text-slate-400" />
          <select
            id="topbar-month-select"
            value={currentMonth}
            onChange={(e) => onMonthYearChange(Number(e.target.value), currentYear)}
            className="bg-transparent text-xs font-semibold text-slate-700 outline-none cursor-pointer pr-1"
          >
            {meses.map(m => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
          <span className="text-slate-300">/</span>
          <select
            id="topbar-year-select"
            value={currentYear}
            onChange={(e) => onMonthYearChange(currentMonth, Number(e.target.value))}
            className="bg-transparent text-xs font-semibold text-slate-700 outline-none cursor-pointer"
          >
            {anos.map(a => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </div>

        {/* Dropdown Filtro de Status */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 hover:border-slate-300 transition-colors">
          <Filter size={14} className="text-slate-400" />
          <select
            id="topbar-status-select"
            value={statusFilter}
            onChange={(e) => onStatusFilterChange(e.target.value as any)}
            className="bg-transparent text-xs font-semibold text-slate-700 outline-none cursor-pointer"
          >
            <option value="TODAS">Todas as Transações</option>
            <option value="PENDENTES">Apenas Pendentes (⏳)</option>
            <option value="CONSOLIDADOS">Apenas Consolidados (✅)</option>
          </select>
        </div>

        {/* Campo Buscar Lançamentos (Mover de Busca Rápida) */}
        <div className="relative flex items-center bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 hover:border-slate-300 focus-within:border-emerald-500 focus-within:bg-white transition-all w-48 focus-within:w-64">
          <Search size={14} className="text-slate-400 mr-2 flex-shrink-0" />
          <input
            id="topbar-search-input"
            type="text"
            placeholder="Buscar lançamentos..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full bg-transparent text-xs font-semibold text-slate-700 outline-none placeholder-slate-400 font-sans"
          />
        </div>
      </div>

      {/* Botões de Ações e Lotes */}
      <div className="flex flex-wrap items-center gap-2">
        {/* Batch Operations Zone */}
        {selectedCount > 0 ? (
          <div className="flex items-center gap-1.5 bg-emerald-50/70 border border-emerald-100 rounded-lg p-1 animate-fade-in">
            <span className="text-[11px] font-bold text-emerald-800 px-2 font-mono">
              {selectedCount} {selectedCount === 1 ? 'selecionado' : 'selecionados'}
            </span>

            {/* Confirmar / Consolidar em Lote */}
            <button
              onClick={onBatchConsolidate}
              title="Confirmar lançamentos selecionados"
              className="flex items-center gap-1 bg-white hover:bg-emerald-600 hover:text-white border border-emerald-200 hover:border-emerald-600 text-emerald-700 px-2.5 py-1 rounded-md text-[11px] font-bold tracking-tight transition-all cursor-pointer"
            >
              <Check size={12} />
              Confirmar
            </button>

            {/* Alterar Categoria em Lote */}
            <div className="relative group/cat">
              <button
                className="flex items-center gap-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 px-2.5 py-1 rounded-md text-[11px] font-bold tracking-tight transition-all cursor-pointer"
              >
                <FolderOpen size={12} />
                Mudar Categoria
              </button>
              {/* Dropdown menu on hover/click */}
              <div className="absolute right-0 top-full pt-1 hidden group-hover/cat:block hover:block z-30">
                <div className="bg-white border border-slate-200 rounded-lg shadow-xl py-1 w-48 max-h-56 overflow-y-auto">
                  <div className="px-2.5 py-1 text-[9px] font-extrabold text-slate-400 uppercase tracking-widest border-b border-slate-100">
                    Selecione Categoria
                  </div>
                  {subCategorias.map(sub => (
                    <button
                      key={sub.id}
                      onClick={() => onBatchChangeCategory(sub.id)}
                      className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 transition-colors"
                    >
                      {sub.descricao}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Excluir em Lote */}
            <button
              onClick={onBatchDelete}
              title="Excluir lançamentos selecionados"
              className="flex items-center gap-1 bg-rose-50 hover:bg-rose-600 hover:text-white border border-rose-100 hover:border-rose-600 text-rose-700 px-2.5 py-1 rounded-md text-[11px] font-bold tracking-tight transition-all cursor-pointer"
            >
              <Trash size={12} />
              Excluir
            </button>
          </div>
        ) : null}

        {/* Exportar Documentos / Visualizador de Firebase */}
        <button
          onClick={onOpenExportView}
          className="flex items-center gap-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 hover:border-slate-300 text-slate-700 px-3 py-2 rounded-lg text-xs font-bold tracking-tight transition-all cursor-pointer"
        >
          <Download size={13} />
          Exportar dados
        </button>

        {/* Adicionar Transação */}
        <button
          onClick={onOpenAddDialog}
          className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm shadow-emerald-600/15 font-bold tracking-tight text-xs px-4 py-2 rounded-lg transition-all transform hover:-translate-y-0.5 cursor-pointer"
        >
          <Plus size={14} className="stroke-[3]" />
          Adicionar lançamento
        </button>
      </div>
    </header>
  );
}
