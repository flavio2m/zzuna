import React from 'react';
import { LancamentoComDetalhes, ItemLancamento, Categoria, Conta, Cartao, CentroCusto } from '../types';
import { CheckSquare, Square, ChevronRight, HelpCircle, Receipt, ArrowDownRight, ArrowUpRight, Link2, CreditCard, Wallet, Layers } from 'lucide-react';

interface TransactionListProps {
  transactions: LancamentoComDetalhes[];
  selectedIds: string[];
  onToggleSelect: (id: string) => void;
  onSelectAllForToday: (date: string, ids: string[]) => void;
  onEditTransaction: (transaction: LancamentoComDetalhes) => void;
  categorias: Categoria[];
  contas: Conta[];
  cartoes: Cartao[];
  centrosCusto: CentroCusto[];
}

export default function TransactionList({
  transactions,
  selectedIds,
  onToggleSelect,
  onSelectAllForToday,
  onEditTransaction,
  categorias,
  contas,
  cartoes,
  centrosCusto
}: TransactionListProps) {
  
  // Helpers for labels
  const getCategoriaDesc = (id: string): string => {
    return categorias.find(c => c.id === id)?.descricao || 'Sem Categoria';
  };

  const getCentroCustoDesc = (id: string): string => {
    return centrosCusto.find(cc => cc.id === id)?.descricao || 'Geral';
  };

  const getOrigemNome = (tipo: 'CONTA' | 'CARTAO', id: string): string => {
    if (tipo === 'CONTA') {
      return contas.find(c => c.id === id)?.descricao || 'Conta';
    } else {
      return cartoes.find(c => c.id === id)?.descricao || 'Cartão';
    }
  };

  // Group by date
  const groups: Record<string, LancamentoComDetalhes[]> = {};
  transactions.forEach(t => {
    if (!groups[t.data]) {
      groups[t.data] = [];
    }
    groups[t.data].push(t);
  });

  // Sort dates descending
  const sortedDates = Object.keys(groups).sort((a, b) => b.localeCompare(a));

  const formatHeaderDate = (dateStr: string): string => {
    const weekdays = [
      'Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira',
      'Quinta-feira', 'Sexta-feira', 'Sábado'
    ];
    // Avoid local timezone shift by parsing ISO with absolute time
    const date = new Date(dateStr + 'T00:00:00');
    const d = String(date.getDate()).padStart(2, '0');
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const y = date.getFullYear();
    const weekday = weekdays[date.getDay()];

    return `${d}/${m}/${y}, ${weekday}`;
  };

  // Balance calculation for a specific day
  const getDayBalance = (dayTransactions: LancamentoComDetalhes[]): number => {
    return dayTransactions.reduce((acc, t) => {
      if (t.tipo === 'RECEITA') {
        return acc + t.valorTotal;
      } else if (t.tipo === 'DESPESA') {
        return acc - t.valorTotal;
      }
      return acc; // TRANSFERENCIA is neutral or handled in original accounts
    }, 0);
  };

  if (transactions.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-12 bg-slate-50 font-sans select-none text-center">
        <Receipt size={48} className="text-slate-300 mb-4 animate-bounce" />
        <h3 className="font-semibold text-slate-800 text-sm">Nenhum lançamento encontrado</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-sm">
          Experimente alterar os filtros na barra lateral, selecionar outro mês ou adicionar uma nova transação.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-6 space-y-4 font-sans select-none">
      {sortedDates.map(dateStr => {
        const dayTransactions = groups[dateStr];
        const dayBalance = getDayBalance(dayTransactions);
        const dayIds = dayTransactions.map(t => t.id);
        const allDaySelected = dayIds.every(id => selectedIds.includes(id));

        return (
          <div key={dateStr} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden transition-all hover:shadow-md">
            {/* Dynamic Day Header Group */}
            <div className="bg-slate-50/60 px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {/* Select All for today toggle checkbox */}
                <button
                  onClick={() => onSelectAllForToday(dateStr, dayIds)}
                  className="text-slate-400 hover:text-slate-600 transition-colors"
                >
                  {allDaySelected ? (
                    <CheckSquare size={14} className="text-emerald-500" />
                  ) : (
                    <Square size={14} className="text-slate-300" />
                  )}
                </button>
                <span className="text-xs font-bold text-slate-800 tracking-tight">
                  {formatHeaderDate(dateStr)}
                </span>
              </div>
              
              {/* Daily Balance Summary */}
              <div className="flex items-center gap-1.5 font-mono">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Saldo do Dia:</span>
                <span className={`text-xs font-bold ${
                  dayBalance > 0 ? 'text-emerald-600' : dayBalance < 0 ? 'text-rose-600' : 'text-slate-500'
                }`}>
                  {dayBalance > 0 ? '+' : ''}R$ {dayBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            {/* List of Transactions of that day */}
            <div className="divide-y divide-slate-100">
              {dayTransactions.map(t => {
                const isChecked = selectedIds.includes(t.id);
                const isExpense = t.tipo === 'DESPESA';
                const isIncome = t.tipo === 'RECEITA';
                const isTransfer = t.tipo === 'TRANSFERENCIA';
                
                // If there are multiple items, represent Rateio (Split)
                const isRateio = t.itens.length > 1;
                
                return (
                  <div
                    key={t.id}
                    className={`flex items-center justify-between px-4 py-3 bg-white hover:bg-slate-50/80 transition-all cursor-pointer group ${
                      isChecked ? 'bg-emerald-50/20' : ''
                    }`}
                    onClick={() => onEditTransaction(t)}
                  >
                    {/* Left Checkbox and Metadata indicators */}
                    <div className="flex items-center gap-3 min-w-0 flex-1 pr-4">
                      {/* Select Item Checkbox */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleSelect(t.id);
                        }}
                        className="text-slate-400 hover:text-slate-600 transition-colors flex-shrink-0"
                      >
                        {isChecked ? (
                          <CheckSquare size={15} className="text-emerald-500" />
                        ) : (
                          <Square size={15} className="text-slate-300 group-hover:text-slate-400" />
                        )}
                      </button>

                      {/* Transaction Type Indicator Icon */}
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        isIncome 
                          ? 'bg-emerald-50 text-emerald-600' 
                          : isExpense 
                            ? 'bg-rose-50 text-rose-600' 
                            : 'bg-indigo-50 text-indigo-600'
                      }`}>
                        {isIncome ? (
                          <ArrowUpRight size={15} className="stroke-[2.5]" />
                        ) : isExpense ? (
                          <ArrowDownRight size={15} className="stroke-[2.5]" />
                        ) : (
                          <Layers size={15} className="stroke-[2.5]" />
                        )}
                      </div>

                      {/* Description + Origin + Items details */}
                      <div className="min-w-0 space-y-0.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-semibold text-slate-800 truncate group-hover:text-emerald-600 transition-colors" title={t.descricao}>
                            {t.descricao}
                          </span>

                          {/* Installment Badge */}
                          {t.parcelaNumero !== null && t.totalParcelas !== null && (
                            <span className="bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] px-1.5 py-0.2 rounded font-mono font-semibold">
                              ({t.parcelaNumero}/{t.totalParcelas})
                            </span>
                          )}

                          {/* Group badge (if linked to group) */}
                          {t.grupoId && (
                            <span className="bg-slate-100 border border-slate-200 text-slate-600 text-[9px] px-1.5 py-0.2 rounded flex items-center gap-0.5 font-mono">
                              <Link2 size={9} /> {t.tipoGrupo === 'REPLICACAO' ? 'Replicado' : 'Parcelado'}
                            </span>
                          )}

                          {/* Recurrent entry indicator */}
                          {t.recorrente && (
                            <span className="bg-emerald-50 text-emerald-700 text-[9px] px-1.5 py-0.2 rounded font-semibold uppercase tracking-wider scale-95 origin-left">
                              Recorrente
                            </span>
                          )}

                          {/* Rateio indicator */}
                          {isRateio && (
                            <span className="bg-teal-50 border border-teal-100 text-teal-700 text-[9px] px-1.5 py-0.2 rounded font-semibold uppercase tracking-wider scale-95 origin-left">
                              Rateio Multi-Categoria
                            </span>
                          )}
                        </div>

                        {/* Account + Category Info row */}
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 font-medium">
                          <span className="flex items-center gap-0.5 bg-slate-50 border border-slate-100 rounded px-1 text-slate-500 font-semibold truncate max-w-[140px]">
                            {t.tipoOrigem === 'CONTA' ? <Wallet size={10} /> : <CreditCard size={10} />}
                            {t.origemNome}
                          </span>
                          <span className="text-slate-300">•</span>
                          {isRateio ? (
                            <span className="text-teal-600 font-bold">
                              {t.itens.length} divisões de categorias (ver rateio)
                            </span>
                          ) : (
                            <span className="text-slate-500 font-medium truncate">
                              {getCategoriaDesc(t.itens[0]?.categoriaId || '')}
                            </span>
                          )}
                          <span className="text-slate-300">•</span>
                          <span className="text-slate-500 font-semibold italic">
                            CC: {getCentroCustoDesc(t.itens[0]?.centroCustoId || '')}
                          </span>
                        </div>

                        {/* Expand rateio category breakdown if active */}
                        {isRateio && (
                          <div className="pt-1 flex flex-wrap gap-1.5 max-w-lg">
                            {t.itens.map((it, idx) => (
                              <div key={idx} className="bg-teal-50/50 border border-teal-100/40 text-teal-850 px-1.5 py-0.5 rounded text-[9px] font-mono flex items-center gap-1">
                                <span className="font-bold text-teal-800">{getCategoriaDesc(it.categoriaId)}:</span>
                                <span className="font-semibold">R$ {it.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                                <span className="opacity-40 italic">({getCentroCustoDesc(it.centroCustoId)})</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right Price section with visual labels */}
                    <div className="flex items-center gap-3 flex-shrink-0">
                      {/* Consolidation badge */}
                      {t.status === 'CONSOLIDADO' ? (
                        <span className="bg-emerald-100/70 border border-emerald-200 text-emerald-800 text-[10px] font-extrabold px-1.5 py-0.5 rounded font-mono uppercase tracking-wider" title="Consolidado e Integrado ao Extrato">
                          Ativo
                        </span>
                      ) : (
                        <span className="bg-orange-100/60 border border-orange-200 text-orange-800 text-[10px] font-extrabold px-1.5 py-0.5 rounded font-mono uppercase tracking-wider" title="Envio pendente para conciliação">
                          Pendente
                        </span>
                      )}

                      {/* Currency Display */}
                      <span className={`font-mono text-xs font-black tracking-tight ${
                        isIncome ? 'text-emerald-600' : isExpense ? 'text-rose-600' : 'text-slate-600 font-bold'
                      }`}>
                        {isIncome ? '+R$ ' : '-R$ '}{t.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                      
                      <ChevronRight size={14} className="text-slate-300 group-hover:text-emerald-500 transform group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
