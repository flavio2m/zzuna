import React, { useState } from 'react';
import { Conta, Cartao, Categoria, TipoOrigem } from '../types';
import { ChevronDown, ChevronRight, CheckSquare, Square, Folder, Search, Wallet, CreditCard, Layers, Filter } from 'lucide-react';

interface SidebarProps {
  contas: Conta[];
  cartoes: Cartao[];
  categorias: Categoria[];
  checkedContaIds: string[];
  checkedCartaoIds: string[];
  onToggleConta: (id: string | 'CLEAR_ALL') => void;
  onToggleCartao: (id: string | 'CLEAR_ALL') => void;
  onClearAllOrigens: () => void;
  checkedCategoryIds: string[];
  onToggleCategoryAndChildren: (catId: string) => void;
}

export default function Sidebar({
  contas,
  cartoes,
  categorias,
  checkedContaIds,
  checkedCartaoIds,
  onToggleConta,
  onToggleCartao,
  onClearAllOrigens,
  checkedCategoryIds,
  onToggleCategoryAndChildren
}: SidebarProps) {
  // Local sidebar filter query state (to filter accounts, credit cards, and categories)
  const [sidebarFilter, setSidebarFilter] = useState('');

  // Tree component expanded states
  const [expandedCats, setExpandedCats] = useState<Record<string, boolean>>({
    'cat_alimentacao': true,
    'cat_moradia': true,
    'cat_vestuario': true,
    'cat_receitas': true,
    'cat_supermercado': true,
    'cat_servicos': true,
  });

  // Section minimizer states
  const [isContasExpanded, setIsContasExpanded] = useState(true);
  const [isCartoesExpanded, setIsCartoesExpanded] = useState(true);
  const [isCategoriasExpanded, setIsCategoriasExpanded] = useState(true);

  const toggleExpand = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedCats(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Helper recursive function to check if a category matches search key or has children that matches
  const matchesCategoryFilter = (catId: string, filterText: string): boolean => {
    if (!filterText) return true;
    const cat = categorias.find(c => c.id === catId);
    if (!cat) return false;
    
    if (cat.descricao.toLowerCase().includes(filterText.toLowerCase())) {
      return true;
    }
    
    const children = categorias.filter(c => c.parentId === catId);
    return children.some(child => matchesCategoryFilter(child.id, filterText));
  };

  // Organize flat list of categories into hierarchical trees
  const level0 = categorias.filter(c => c.parentId === null);
  const getChildren = (parentId: string) => categorias.filter(c => c.parentId === parentId);

  // Recursive category item renderer
  const renderCategoryNode = (cat: Categoria, level: number) => {
    const children = getChildren(cat.id).filter(child => matchesCategoryFilter(child.id, sidebarFilter));
    const hasChildren = children.length > 0;
    // Auto-expand any matching categories when search filter is active
    const isExpanded = !!expandedCats[cat.id] || (sidebarFilter !== '' && matchesCategoryFilter(cat.id, sidebarFilter));
    const isChecked = checkedCategoryIds.includes(cat.id);

    return (
      <div key={cat.id} className="select-none text-xs font-sans text-gray-700">
        <div 
          className="flex items-center hover:bg-slate-100/70 p-1.5 rounded-md cursor-pointer group transition-all"
          style={{ paddingLeft: `${level * 16 + 8}px` }}
          onClick={() => onToggleCategoryAndChildren(cat.id)}
        >
          {/* Collapse/Expand indicator */}
          <div 
            onClick={(e) => toggleExpand(cat.id, e)} 
            className="p-1 rounded hover:bg-slate-200/60 text-gray-500 mr-1 flex items-center justify-center transition-colors"
          >
            {hasChildren ? (
              isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />
            ) : (
              <span className="w-[14px]" />
            )}
          </div>

          {/* Custom Checkbox */}
          <div className="text-slate-500 hover:text-slate-800 mr-2 transition-all flex items-center">
            {isChecked ? (
              <CheckSquare size={15} className="text-emerald-500 fill-emerald-50/20" />
            ) : (
              <Square size={15} className="text-slate-300 group-hover:text-slate-400" />
            )}
          </div>

          {/* Level Icon */}
          <Folder size={13} className={`mr-2 ${level === 0 ? 'text-slate-500' : level === 1 ? 'text-slate-400' : 'text-slate-300'}`} />

          {/* Description */}
          <span className={`text-[13px] tracking-tight ${isChecked ? 'font-medium text-slate-900' : 'text-slate-600'}`}>
            {cat.descricao}
          </span>
        </div>

        {hasChildren && isExpanded && (
          <div className="mt-0.5 space-y-0.5 border-l border-slate-100 ml-[18px]">
            {children.map(child => renderCategoryNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside id="sidebar-zzuna" className="w-[280px] h-full flex-shrink-0 bg-white border-r border-slate-200 flex flex-col font-sans select-none overflow-y-auto">
      {/* ZZuna App Header */}
      <div className="p-5 border-b border-slate-100 flex items-center gap-3 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 flex-shrink-0">
        <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center shadow-md">
          <span className="text-white font-bold text-lg tracking-tight font-sans">Z</span>
        </div>
        <div>
          <h1 className="font-extrabold text-xl text-slate-800 tracking-tight leading-4">ZZuna</h1>
          <span className="text-[10px] text-emerald-600 font-mono tracking-wider uppercase font-bold">Personal Finance</span>
        </div>
      </div>

      {/* Local Menu Filter */}
      <div className="p-4 border-b border-slate-100 flex-shrink-0">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Filtrar Opções</span>
        <div className="relative">
          <input
            id="sidebar-local-filter-input"
            type="text"
            placeholder="Filtrar contas e categorias..."
            value={sidebarFilter}
            onChange={(e) => setSidebarFilter(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-emerald-500 focus:bg-white transition-all font-sans"
          />
          <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
        </div>
      </div>

      {/* Origens Ativas (Contas e Cartões) */}
      <div className="p-4 border-b border-slate-100 flex-shrink-0 space-y-4">
        <div>
          {/* Accounts Section */}
          <div className="space-y-1 pb-3 border-b border-slate-50">
            <div 
              onClick={() => setIsContasExpanded(!isContasExpanded)}
              className="flex justify-between items-center px-1 py-1 cursor-pointer select-none hover:bg-slate-50 rounded transition-colors group mb-1.5"
            >
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                {(isContasExpanded || sidebarFilter !== '') ? <ChevronDown size={12} className="text-slate-400" /> : <ChevronRight size={12} className="text-slate-400" />}
                Contas Correntes
              </span>
              <div className="flex items-center gap-1.5">
                {checkedContaIds.length > 0 ? (
                  <button 
                    onClick={(e) => { e.stopPropagation(); onToggleConta('CLEAR_ALL'); }}
                    title="Filtro ativo. Clique para mostrar todas as contas"
                    className="text-emerald-500 hover:text-emerald-600 font-bold p-1 rounded hover:bg-emerald-50 transition-all flex items-center justify-center cursor-pointer"
                  >
                    <Filter size={13} className="animate-pulse" />
                  </button>
                ) : (
                  <span className="text-slate-300 p-1" title="Mostrando todas as contas">
                    <Layers size={13} />
                  </span>
                )}
              </div>
            </div>
            
            {(isContasExpanded || sidebarFilter !== '') && (
              <div className="space-y-1">
                {contas.filter(c => c.descricao.toLowerCase().includes(sidebarFilter.toLowerCase())).map(conta => (
                  <div
                    key={conta.id}
                    onClick={() => conta.ativo && onToggleConta(conta.id)}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium tracking-tight cursor-pointer select-none transition-all ${
                      !conta.ativo ? 'opacity-40 cursor-not-allowed' : 'hover:bg-slate-50 text-slate-600'
                    } ${
                      checkedContaIds.includes(conta.id) ? 'bg-emerald-50 text-slate-900 font-semibold' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate min-w-0">
                      <div className="text-slate-500 hover:text-slate-800 flex-shrink-0 flex items-center">
                        {checkedContaIds.includes(conta.id) ? (
                          <CheckSquare size={14} className="text-emerald-500 fill-emerald-50/20" />
                        ) : (
                          <Square size={14} className="text-slate-300" />
                        )}
                      </div>
                      <Wallet size={13} className="text-slate-400 flex-shrink-0" /> 
                      <span className="truncate">{conta.descricao}</span>
                    </div>
                    <span className={`font-mono text-[11px] font-medium flex-shrink-0 ${conta.saldo >= 0 ? 'text-slate-700' : 'text-rose-600'}`}>
                      R$ {conta.saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Credit Cards Section */}
          <div className="space-y-1 pt-3">
            <div 
              onClick={() => setIsCartoesExpanded(!isCartoesExpanded)}
              className="flex justify-between items-center px-1 py-1 cursor-pointer select-none hover:bg-slate-50 rounded transition-colors group mb-1.5"
            >
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                {(isCartoesExpanded || sidebarFilter !== '') ? <ChevronDown size={12} className="text-slate-400" /> : <ChevronRight size={12} className="text-slate-400" />}
                Cartões de Crédito
              </span>
              <div className="flex items-center gap-1.5">
                {checkedCartaoIds.length > 0 ? (
                  <button 
                    onClick={(e) => { e.stopPropagation(); onToggleCartao('CLEAR_ALL'); }}
                    title="Filtro ativo. Clique para mostrar todos os cartões"
                    className="text-emerald-500 hover:text-emerald-600 font-bold p-1 rounded hover:bg-emerald-50 transition-all flex items-center justify-center cursor-pointer"
                  >
                    <Filter size={13} className="animate-pulse" />
                  </button>
                ) : (
                  <span className="text-slate-300 p-1" title="Mostrando todos os cartões">
                    <Layers size={13} />
                  </span>
                )}
              </div>
            </div>
            
            {(isCartoesExpanded || sidebarFilter !== '') && (
              <div className="space-y-1">
                {cartoes.filter(ca => ca.descricao.toLowerCase().includes(sidebarFilter.toLowerCase())).map(cartao => (
                  <div
                    key={cartao.id}
                    onClick={() => cartao.ativo && onToggleCartao(cartao.id)}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium tracking-tight cursor-pointer select-none transition-all ${
                      !cartao.ativo ? 'opacity-40 cursor-not-allowed' : 'hover:bg-slate-50 text-slate-600'
                    } ${
                      checkedCartaoIds.includes(cartao.id) ? 'bg-emerald-50 text-slate-900 font-semibold' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate min-w-0">
                      <div className="text-slate-500 hover:text-slate-800 flex-shrink-0 flex items-center">
                        {checkedCartaoIds.includes(cartao.id) ? (
                          <CheckSquare size={14} className="text-emerald-500 fill-emerald-50/20" />
                        ) : (
                          <Square size={14} className="text-slate-300" />
                        )}
                      </div>
                      <CreditCard size={13} className="text-slate-400 flex-shrink-0" />
                      <span className="truncate">{cartao.descricao}</span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-700 font-medium flex-shrink-0">
                      Dia {cartao.diaFechamento}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Categorias (Tree) */}
      <div className="p-4 flex-1 overflow-y-auto">
        <div 
          onClick={() => setIsCategoriasExpanded(!isCategoriasExpanded)}
          className="flex justify-between items-center px-1 py-1 cursor-pointer select-none hover:bg-slate-50 rounded transition-colors group mb-2"
        >
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            {(isCategoriasExpanded || sidebarFilter !== '') ? <ChevronDown size={12} className="text-slate-400" /> : <ChevronRight size={12} className="text-slate-400" />}
            Categorias
          </span>
          <div className="flex items-center gap-1.55">
            {checkedCategoryIds.length > 0 ? (
              <button 
                onClick={(e) => { e.stopPropagation(); onToggleCategoryAndChildren('CLEAR_ALL'); }}
                title="Filtro ativo. Clique para mostrar todas as categorias"
                className="text-emerald-500 hover:text-emerald-600 font-bold p-1 rounded hover:bg-emerald-50 transition-all flex items-center justify-center cursor-pointer"
              >
                <Filter size={13} className="animate-pulse" />
              </button>
            ) : (
              <span className="text-slate-300 p-1" title="Mostrando todas as categorias">
                <Layers size={13} />
              </span>
            )}
          </div>
        </div>
        {(isCategoriasExpanded || sidebarFilter !== '') && (
          <div className="space-y-1">
            {level0.filter(cat => matchesCategoryFilter(cat.id, sidebarFilter)).map(cat => renderCategoryNode(cat, 0))}
          </div>
        )}
      </div>
    </aside>
  );
}
