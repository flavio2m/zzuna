import React from 'react';
import { LancamentoComDetalhes, ItemLancamento, Categoria, CentroCusto } from '../types';
import { BarChart3, PieChart, Landmark, TrendingUp, AlertCircle } from 'lucide-react';

interface FinancialReportsProps {
  transactions: LancamentoComDetalhes[];
  categorias: Categoria[];
  centrosCusto: CentroCusto[];
}

export default function FinancialReports({
  transactions,
  categorias,
  centrosCusto
}: FinancialReportsProps) {
  
  // Extract all sub-items (rateio) from the transactions to formulate accurate reports
  const allItens: ItemLancamento[] = [];
  transactions.forEach(t => {
    // Only compile expense items for standard category/cc distributions
    if (t.tipo === 'DESPESA') {
      allItens.push(...t.itens);
    }
  });

  const totalExpenseSum = allItens.reduce((acc, it) => acc + it.valor, 0);

  // Group strictly by CategoriaId (REQUISITO 6: USAR ITENS)
  const categoryTotals: Record<string, number> = {};
  allItens.forEach(it => {
    categoryTotals[it.categoriaId] = (categoryTotals[it.categoriaId] || 0) + it.valor;
  });

  // Group strictly by CentroCustoId (REQUISITO 6: USAR ITENS)
  const ccTotals: Record<string, number> = {};
  allItens.forEach(it => {
    ccTotals[it.centroCustoId] = (ccTotals[it.centroCustoId] || 0) + it.valor;
  });

  // Organize for rendering
  const getCategoryDesc = (id: string): string => {
    return categorias.find(c => c.id === id)?.descricao || 'Outros';
  };

  const getCCDesc = (id: string): string => {
    return centrosCusto.find(cc => cc.id === id)?.descricao || 'Geral';
  };

  const categoryRows = Object.entries(categoryTotals)
    .map(([catId, total]) => ({
      desc: getCategoryDesc(catId),
      total,
      pct: totalExpenseSum > 0 ? (total / totalExpenseSum) * 100 : 0
    }))
    .sort((a, b) => b.total - a.total);

  const ccRows = Object.entries(ccTotals)
    .map(([ccId, total]) => ({
      desc: getCCDesc(ccId),
      total,
      pct: totalExpenseSum > 0 ? (total / totalExpenseSum) * 100 : 0
    }))
    .sort((a, b) => b.total - a.total);

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 space-y-6 font-sans">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <BarChart3 size={16} />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-800">Relatórios Financeiros ZZuna</h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Métrica de Rateio de Itens Ativos ({transactions.length} Lançamentos)</p>
          </div>
        </div>
        
        <div className="bg-slate-50 border border-slate-200/50 rounded-lg px-3 py-1.5 text-right font-mono">
          <span className="block text-[8px] uppercase text-slate-400 font-extrabold tracking-wider">Despesa Total</span>
          <span className="text-sm font-black text-rose-600">R$ {totalExpenseSum.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
        </div>
      </div>

      {allItens.length === 0 ? (
        <div className="py-12 text-center text-slate-400 text-xs">
          Nenhuma despesa ativa no filtro corrente para emitir relatórios.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Category split report */}
          <div className="space-y-4">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 border-b border-slate-50 pb-2">
              <PieChart size={14} className="text-slate-400" />
              <span>Despesas por Categoria (Rateio de Itens)</span>
            </div>

            <div className="space-y-3">
              {categoryRows.map((row, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-[11px] font-semibold text-slate-700">
                    <span className="truncate">{row.desc}</span>
                    <span className="font-mono">
                      R$ {row.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} ({row.pct.toFixed(1)}%)
                    </span>
                  </div>
                  {/* Progress bar indicator */}
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500 rounded-full transition-all"
                      style={{ width: `${row.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cost center split report */}
          <div className="space-y-4">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 border-b border-slate-50 pb-2">
              <Landmark size={14} className="text-slate-400" />
              <span>Despesas por Centro de Custo</span>
            </div>

            <div className="space-y-3">
              {ccRows.map((row, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-[11px] font-semibold text-slate-700">
                    <span className="truncate">{row.desc}</span>
                    <span className="font-mono">
                      R$ {row.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} ({row.pct.toFixed(1)}%)
                    </span>
                  </div>
                  {/* Progress bar indicator */}
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-teal-500 rounded-full transition-all"
                      style={{ width: `${row.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* Info indicator regarding logic accuracy */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex gap-2 text-[10px] text-slate-500 select-none">
        <AlertCircle size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
        <span>
          Aviso de Exatidão: Conforme estipulado pelas diretrizes conceituais do ZZuna, este gráfico é calculado a partir de **itens de lançamento** individuais e reais. Isso garante uma partição fidedigna quando um único pagamento em cartão de crédito compreende múltiplos centros de custos ou categorias (Rateio).
        </span>
      </div>
    </div>
  );
}
