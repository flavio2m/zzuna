import React, { useState } from 'react';
import { Copy, Check, FileCode, Cpu, Layout, Layers } from 'lucide-react';

export default function FlutterCodeViewer() {
  const [activeTab, setActiveTab] = useState<'models' | 'providers' | 'screen' | 'widgets'>('models');
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const codeBlocks = {
    models: `/// ZZuna Financial Domain Models
/// Following standard Flutter conventions & clean types
import 'dart:convert';

enum TipoLancamento { RECEITA, DESPESA, TRANSFERENCIA }
enum TipoOrigem { CONTA, CARTAO }
enum StatusLancamento { PENDENTE, CONSOLIDADO }
enum StatusDocumento { ABERTA, FECHADA }
enum TipoDocumento { FATURA, EXTRATO }

class Banco {
  final String id;
  final String descricao;
  final String sigla;
  final String iconeUrl;
  final bool ativo;

  Banco({
    required this.id,
    required this.descricao,
    required this.sigla,
    required this.iconeUrl,
    required this.ativo,
  });
}

class Conta {
  final String id;
  final String descricao;
  final String bancoId;
  final double saldo;
  final bool ativo;

  Conta({
    required this.id,
    required this.descricao,
    required this.bancoId,
    required this.saldo,
    required this.ativo,
  });
}

class Cartao {
  final String id;
  final String descricao;
  final String bancoId;
  final int diaFechamento;
  final double saldo;
  final bool ativo;

  Cartao({
    required this.id,
    required this.descricao,
    required this.bancoId,
    required this.diaFechamento,
    required this.saldo,
    required this.ativo,
  });
}

class Documento {
  final String id;
  final TipoDocumento tipo;
  final String origemId;
  final DateTime dataInicio;
  final DateTime dataFim;
  final int mesReferencia;
  final int anoReferencia;
  final StatusDocumento status;

  Documento({
    required this.id,
    required this.tipo,
    required this.origemId,
    required this.dataInicio,
    required this.dataFim,
    required this.mesReferencia,
    required this.anoReferencia,
    required this.status,
  });
}

class Lancamento {
  final String id;
  final DateTime data;
  final String descricao;
  final TipoLancamento tipo;
  final double valorTotal;
  final TipoOrigem tipoOrigem;
  final String origemId;
  final String documentoId;
  final StatusLancamento status;
  final String? grupoId;
  final String? tipoGrupo; // 'PARCELAMENTO' | 'REPLICACAO' | 'TRANSFERENCIA'
  final int? parcelaNumero;
  final int? totalParcelas;
  final String observacao;
  final bool recorrente;

  Lancamento({
    required this.id,
    required this.data,
    required this.descricao,
    required this.tipo,
    required this.valorTotal,
    required this.tipoOrigem,
    required this.origemId,
    required this.documentoId,
    required this.status,
    this.grupoId,
    this.tipoGrupo,
    this.parcelaNumero,
    this.totalParcelas,
    required this.observacao,
    required this.recorrente,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'data': data.toIso8601String().substring(0, 10),
      'descricao': descricao,
      'tipo': tipo.name,
      'valorTotal': valorTotal,
      'tipoOrigem': tipoOrigem.name,
      'origemId': origemId,
      'documentoId': documentoId,
      'status': status.name,
      'grupoId': grupoId,
      'tipoGrupo': tipoGrupo,
      'parcelaNumero': parcelaNumero,
      'totalParcelas': totalParcelas,
      'observacao': observacao,
      'recorrente': recorrente,
    };
  }

  factory Lancamento.fromMap(Map<String, dynamic> map) {
    return Lancamento(
      id: map['id'] ?? '',
      data: DateTime.parse(map['data']),
      descricao: map['descricao'] ?? '',
      tipo: TipoLancamento.values.byName(map['tipo']),
      valorTotal: (map['valorTotal'] as num).toDouble(),
      tipoOrigem: TipoOrigem.values.byName(map['tipoOrigem']),
      origemId: map['origemId'] ?? '',
      documentoId: map['documentoId'] ?? '',
      status: StatusLancamento.values.byName(map['status']),
      grupoId: map['grupoId'],
      tipoGrupo: map['tipoGrupo'],
      parcelaNumero: map['parcelaNumero'],
      totalParcelas: map['totalParcelas'],
      observacao: map['observacao'] ?? '',
      recorrente: map['recorrente'] ?? false,
    );
  }
}

class ItemLancamento {
  final String id;
  final String lancamentoId;
  final String categoriaId;
  final String centroCustoId;
  final double valor;

  ItemLancamento({
    required this.id,
    required this.lancamentoId,
    required this.categoriaId,
    required this.centroCustoId,
    required this.valor,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'lancamentoId': lancamentoId,
    'categoriaId': categoriaId,
    'centroCustoId': centroCustoId,
    'valor': valor,
  };
}
`,
    providers: `/// ZZuna Riverpod State Management Providers
/// Implementing reactive state filtering and transaction updates
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'models.dart';

// Current selected month & year simulation
class MonthYear {
  final int month;
  final int year;
  MonthYear(this.month, this.year);
}

class MonthYearNotifier extends StateNotifier<MonthYear> {
  MonthYearNotifier() : super(MonthYear(3, 2026));

  void update(int month, int year) {
    state = MonthYear(month, year);
  }
}

final monthYearProvider = StateNotifierProvider<MonthYearNotifier, MonthYear>((ref) {
  return MonthYearNotifier();
});

// Category multi-select list filters
class CategoryFiltersNotifier extends StateNotifier<Set<String>> {
  CategoryFiltersNotifier() : super(<String>{});

  void toggleCategory(String catId) {
    final updated = Set<String>.from(state);
    if (updated.contains(catId)) {
      updated.remove(catId);
    } else {
      updated.add(catId);
    }
    state = updated;
  }

  void clearAll() {
    state = <String>{};
  }
}

final categoryFiltersProvider = StateNotifierProvider<CategoryFiltersNotifier, Set<String>>((ref) {
  return CategoryFiltersNotifier();
});

// Primary list state (Realtime Database synchronized)
class TransactionState {
  final List<Lancamento> lancamentos;
  final List<ItemLancamento> itens;
  TransactionState({required this.lancamentos, required this.itens});
}

class TransactionNotifier extends StateNotifier<TransactionState> {
  TransactionNotifier() : super(TransactionState(lancamentos: [], itens: []));

  // 6.2 - Adicionar Lançamento Parcelado com Distribuição de Centavos
  void adicioanarParcelado({
    required DateTime data,
    required String descricao,
    required double valorTotal,
    required String origemId,
    required TipoOrigem tipoOrigem,
    required int parcelas,
    required String categoriaId,
    required String centroCustoId,
  }) {
    final grupoId = 'grupo_\${DateTime.now().millisecondsSinceEpoch}';
    
    // Regra: o valor fracionário menor que 1 centavo deve ser somado na primeira parcela.
    final baseValue = (valorTotal / parcelas).floorToDouble();
    final remainingMinutes = double.parse((valorTotal - (baseValue * parcelas)).toStringAsFixed(2));

    for (int i = 1; i <= parcelas; i++) {
      final finalValue = i == 1 ? (baseValue + remainingMinutes) : baseValue;
      final lancId = 'lanc_\${grupoId}_\$i';
      
      // Auto-determinar fatura ou extrato aqui...
      final docId = 'fatura_\${origemId}_\${data.year}_\${data.month + 1}'; 
      
      final lancamento = Lancamento(
        id: lancId,
        data: data.add(Duration(days: 30 * (i - 1))),
        descricao: '\$descricao (\$i/\$parcelas)',
        tipo: TipoLancamento.DESPESA,
        valorTotal: finalValue,
        tipoOrigem: tipoOrigem,
        origemId: origemId,
        documentoId: docId,
        status: StatusLancamento.PENDENTE,
        grupoId: grupoId,
        tipoGrupo: 'PARCELAMENTO',
        parcelaNumero: i,
        totalParcelas: parcelas,
        observacao: 'Gerado automaticamente em lotes',
        recorrente: false,
      );

      final item = ItemLancamento(
        id: 'item_\$lancId',
        lancamentoId: lancId,
        categoriaId: categoriaId,
        centroCustoId: centroCustoId,
        valor: finalValue,
      );

      state = TransactionState(
        lancamentos: [...state.lancamentos, lancamento],
        itens: [...state.itens, item],
      );
    }
  }

  // Múltiplos updates baseados nos usecases de relacionamento
  void editar({required String id, required double novoValor, required String novaDesc}) {
    // ... Realiza update local ou sincroniza direto no Realtime Database
  }
}
`,
    screen: `/// ZZuna Main Screen Layout
/// Employs clean 3-part layout: Left sidebar, Top bar, and Central ledger list
import 'package:flutter/material.dart';
import 'widgets.dart';

class ZZunaHomeView extends StatelessWidget {
  const ZZunaHomeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC), // Tailind Slate 50
      body: Row(
        children: [
          // 1. FIXED LEFT SIDEBAR (Width: 280px)
          const SizedBox(
            width: 280,
            child: SidebarWidget(),
          ),

          // Divider
          Container(
            width: 1,
            color: const Color(0xFFE2E8F0), // Border Slate 200
          ),

          // 2 & 3. DYNAMIC CONTENT AREA (Topbar + TransactionList)
          Expanded(
            child: Column(
              children: [
                // Topbar actions
                const TopbarWidget(),
                
                // Grouped Scrollable ledger list
                Expanded(
                  child: const TransactionListWidget(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
`,
    widgets: `/// ZZuna Widgets and Hierarchical Layouts
/// Formulated according to spec details (Day groups, hover cards, multi-categories)
import 'package:flutter/material.dart';

// Recursively rendered 3-Level Category Tree Node
class CategoryTreeNode extends StatefulWidget {
  final String id;
  final String label;
  final int level;
  final List<CategoryTreeNode> children;
  final bool isChecked;
  final Function(String, bool) onCheckChanged;

  const CategoryTreeNode({
    Key? key,
    required this.id,
    required this.label,
    required this.level,
    this.children = const [],
    required this.isChecked,
    required this.onCheckChanged,
  }) : super(key: key);

  @override
  _CategoryTreeNodeState createState() => _CategoryTreeNodeState();
}

class _CategoryTreeNodeState extends State<CategoryTreeNode> {
  bool _isExpanded = true;

  @override
  Widget build(BuildContext context) {
    final hasChildren = widget.children.isNotEmpty;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(
            left: (widget.level * 16.0) + 8.0, 
            top: 4, 
            bottom: 4
          ),
          child: Row(
            children: [
              // Expand Indicator
              GestureDetector(
                onTap: () {
                  if (hasChildren) {
                    setState(() {
                      _isExpanded = !_isExpanded;
                    });
                  }
                },
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: hasChildren
                      ? Icon(
                          _isExpanded ? Icons.arrow_drop_down : Icons.arrow_right,
                          size: 16,
                          color: Colors.grey[600],
                        )
                      : const SizedBox.shrink(),
                ),
              ),

              // Checked Status Box
              Checkbox(
                value: widget.isChecked,
                onChanged: (val) {
                  widget.onCheckChanged(widget.id, val ?? false);
                },
                activeColor: const Color(0xFF10B981), // Emerald 500
              ),
              
              const Icon(Icons.folder_open_outlined, size: 14, color: Colors.grey),
              const SizedBox(width: 8),

              // Text label and count
              Text(
                widget.label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: widget.isChecked ? FontWeight.bold : FontWeight.normal,
                  color: widget.isChecked ? Colors.black85 : Colors.grey[800],
                ),
              ),
            ],
          ),
        ),

        // Recursive render for sub-branches
        if (hasChildren && _isExpanded)
          ...widget.children,
      ],
    );
  }
}
`
  };

  return (
    <div className="bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col h-[550px] font-sans">
      {/* Panel Top bar */}
      <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
            <FileCode size={16} />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-50">Visualizador de Código Flutter</h3>
            <p className="text-[10px] text-slate-400">Implementação de Referência (com Riverpod &amp; Arquitetura Recomendada)</p>
          </div>
        </div>
        
        {/* Copy button */}
        <button
          onClick={() => handleCopy(codeBlocks[activeTab])}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-100 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border border-slate-700 active:scale-95 cursor-pointer"
        >
          {copied ? (
            <>
              <Check size={13} className="text-emerald-400 stroke-[3]" />
              <span className="text-emerald-400 font-extrabold font-mono text-[11px] uppercase tracking-wider">Copiado!</span>
            </>
          ) : (
            <>
              <Copy size={13} />
              <span>Copiar Arquivo</span>
            </>
          )}
        </button>
      </div>

      {/* Tabs navigation */}
      <div className="bg-slate-950/80 px-4 py-1.5 border-b border-slate-850 flex gap-1">
        <button
          onClick={() => setActiveTab('models')}
          className={`flex items-center gap-1 text-[11px] font-bold px-3 py-1.5 rounded-md transition-colors ${
            activeTab === 'models' ? 'bg-slate-800 text-slate-50' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers size={12} />
          models.dart (Modelos)
        </button>
        <button
          onClick={() => setActiveTab('providers')}
          className={`flex items-center gap-1 text-[11px] font-bold px-3 py-1.5 rounded-md transition-colors ${
            activeTab === 'providers' ? 'bg-slate-800 text-slate-50' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Cpu size={12} />
          providers.dart (Riverpod)
        </button>
        <button
          onClick={() => setActiveTab('screen')}
          className={`flex items-center gap-1 text-[11px] font-bold px-3 py-1.5 rounded-md transition-colors ${
            activeTab === 'screen' ? 'bg-slate-800 text-slate-50' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layout size={12} />
          main_screen.dart (Tela Principal)
        </button>
        <button
          onClick={() => setActiveTab('widgets')}
          className={`flex items-center gap-1 text-[11px] font-bold px-3 py-1.5 rounded-md transition-colors ${
            activeTab === 'widgets' ? 'bg-slate-800 text-slate-50' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode size={12} />
          widgets.dart (Árvore e Componentes)
        </button>
      </div>

      {/* Code Area */}
      <div className="flex-1 p-5 overflow-auto bg-slate-950 font-mono text-xs text-slate-300 leading-relaxed thin-scrollbar">
        <pre className="whitespace-pre">{codeBlocks[activeTab]}</pre>
      </div>
    </div>
  );
}
