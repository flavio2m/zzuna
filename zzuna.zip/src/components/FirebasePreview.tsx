import React from 'react';
import { LancamentoComDetalhes, ItemLancamento, Conta, Cartao, CentroCusto, Categoria } from '../types';
import { Database, Eye, RefreshCw } from 'lucide-react';

interface FirebasePreviewProps {
  lancamentos: LancamentoComDetalhes[];
  contas: Conta[];
  cartoes: Cartao[];
  centrosCusto: CentroCusto[];
  categorias: Categoria[];
}

export default function FirebasePreview({
  lancamentos,
  contas,
  cartoes,
  centrosCusto,
  categorias
}: FirebasePreviewProps) {
  
  // Transform flat structure into relational JSON mimicking Firebase schema
  const buildFirebaseJSON = () => {
    const firebaseDb: Record<string, any> = {
      lancamentos: {},
      itens: {},
      contas: {},
      cartoes: {},
      centroCustos: {},
      categorias: {},
      documentos: {} // Automatically computed documents
    };

    // Populate lookup references
    contas.forEach(c => {
      firebaseDb.contas[c.id] = {
        descricao: c.descricao,
        bancoId: c.bancoId,
        saldo: c.saldo,
        ativo: c.ativo
      };
    });

    cartoes.forEach(ca => {
      firebaseDb.cartoes[ca.id] = {
        descricao: ca.descricao,
        bancoId: ca.bancoId,
        diaFechamento: ca.diaFechamento,
        saldo: ca.saldo,
        ativo: ca.ativo
      };
    });

    centrosCusto.forEach(cc => {
      firebaseDb.centroCustos[cc.id] = {
        descricao: cc.descricao,
        ativo: cc.ativo
      };
    });

    categorias.forEach(cat => {
      firebaseDb.categorias[cat.id] = {
        descricao: cat.descricao,
        parentId: cat.parentId,
        ativo: cat.ativo
      };
    });

    // Populate transactions and their matching child items
    lancamentos.forEach(l => {
      firebaseDb.lancamentos[l.id] = {
        data: l.data,
        descricao: l.descricao,
        tipo: l.tipo,
        valorTotal: l.valorTotal,
        tipoOrigem: l.tipoOrigem,
        origemId: l.origemId,
        documentoId: l.documentoId,
        status: l.status,
        grupoId: l.grupoId,
        tipoGrupo: l.tipoGrupo,
        parcelaNumero: l.parcelaNumero,
        totalParcelas: l.totalParcelas,
        observacao: l.observacao,
        recorrente: l.recorrente
      };

      // Populate items rateio child collection (Case 4.4 / 6.4)
      l.itens.forEach(it => {
        firebaseDb.itens[it.id] = {
          lancamentoId: it.lancamentoId,
          categoriaId: it.categoriaId,
          centroCustoId: it.centroCustoId,
          valor: it.valor
        };
      });
      
      // Auto register document container representation to show documents catalog
      if (!firebaseDb.documentos[l.documentoId]) {
        firebaseDb.documentos[l.documentoId] = {
          tipo: l.tipoOrigem === 'CONTA' ? 'EXTRATO' : 'FATURA',
          origemId: l.origemId,
          status: l.documentoId.includes('2026_1') || l.documentoId.includes('2026_2') ? 'FECHADA' : 'ABERTA'
        };
      }
    });

    return JSON.stringify(firebaseDb, null, 2);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col h-[550px] font-sans text-slate-100 shadow-xl">
      {/* Header */}
      <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
            <Database size={16} />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-50">Sincronizador Firebase Realtime Database</h3>
            <p className="text-[10px] text-teal-400">Preview dinâmico da árvore JSON persistida</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2 bg-teal-500/10 border border-teal-500/20 rounded-full px-3 py-1 text-[9px] font-mono text-teal-400 font-bold uppercase tracking-wider">
          <RefreshCw size={10} className="animate-spin text-teal-400" />
          Live Connected
        </div>
      </div>

      {/* Info Warning */}
      <div className="bg-slate-950/40 px-6 py-2.5 border-b border-slate-850 flex items-center gap-2 text-[10px] text-slate-400">
        <Eye size={12} className="text-teal-500" />
        <span>Adicione, edite ou exclua lançamentos e assista à árvore de dados se estruturando em tempo real.</span>
      </div>

      {/* Code Area */}
      <div className="flex-1 p-5 overflow-auto bg-slate-950 font-mono text-xs text-teal-300 leading-relaxed thin-scrollbar">
        <pre className="whitespace-pre">{buildFirebaseJSON()}</pre>
      </div>
    </div>
  );
}
