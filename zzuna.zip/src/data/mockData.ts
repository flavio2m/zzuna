import { Banco, Conta, Cartao, Documento, Categoria, CentroCusto, Lancamento, ItemLancamento } from '../types';

export const BANCOS: Banco[] = [
  { id: 'bb', descricao: 'Banco do Brasil', sigla: 'BB', iconeUrl: 'https://img.icons8.com/color/48/banco-do-brasil.png', ativo: true },
  { id: 'bradesco', descricao: 'Bradesco', sigla: 'BRA', iconeUrl: 'https://img.icons8.com/color/48/bradesco.png', ativo: true },
  { id: 'itau', descricao: 'Itaú', sigla: 'ITA', iconeUrl: 'https://img.icons8.com/color/48/itau.png', ativo: true },
  { id: 'caixa', descricao: 'Caixa Econômica Federal', sigla: 'CEF', iconeUrl: 'https://img.icons8.com/color/48/caixa.png', ativo: true },
  { id: 'santander', descricao: 'Santander', sigla: 'SAN', iconeUrl: 'https://img.icons8.com/color/48/santander.png', ativo: true },
  { id: 'nubank', descricao: 'Nubank', sigla: 'NUB', iconeUrl: 'https://img.icons8.com/color/48/nubank.png', ativo: true },
  { id: 'sicoob', descricao: 'Sicoob', sigla: 'SCO', iconeUrl: 'https://img.icons8.com/color/48/sicoob.png', ativo: true },
  { id: 'inter', descricao: 'Inter', sigla: 'INT', iconeUrl: 'https://img.icons8.com/color/48/banco-inter.png', ativo: true },
  { id: 'bnb', descricao: 'Banco do Nordeste', sigla: 'BNB', iconeUrl: 'https://img.icons8.com/color/48/bank.png', ativo: true },
  { id: 'sicredi', descricao: 'Sicredi', sigla: 'SIC', iconeUrl: 'https://img.icons8.com/color/48/bank.png', ativo: true },
  { id: 'c6', descricao: 'C6 Bank', sigla: 'C6', iconeUrl: 'https://img.icons8.com/color/48/bank.png', ativo: true },
  { id: 'outros', descricao: 'Outros Bancos', sigla: 'OUT', iconeUrl: 'https://img.icons8.com/color/48/bank.png', ativo: true },
];

export const CONTAS: Conta[] = [
  { id: 'conta_itau', descricao: 'Itaú Corrente', bancoId: 'itau', saldo: 2450.80, ativo: true },
  { id: 'conta_nubank', descricao: 'Nubank Saldo', bancoId: 'nubank', saldo: 11200.00, ativo: true },
  { id: 'conta_bb_poupança', descricao: 'BB Poupança', bancoId: 'bb', saldo: 450.00, ativo: false } // Inativa para testar validação
];

export const CARTOES: Cartao[] = [
  { id: 'cartao_itau', descricao: 'Itaú Visa Click', bancoId: 'itau', diaFechamento: 25, saldo: 5000.00, ativo: true },
  { id: 'cartao_nubank', descricao: 'Nubank Ultra', bancoId: 'nubank', diaFechamento: 10, saldo: 8000.00, ativo: true },
];

export const CENTROS_CUSTO: CentroCusto[] = [
  { id: 'cc_geral', descricao: 'Geral', ativo: true },
  { id: 'cc_marcos', descricao: 'Marcos', ativo: true },
  { id: 'cc_flavia', descricao: 'Flávia', ativo: true },
  { id: 'cc_viagens', descricao: 'Viagem Natal/RN', ativo: true },
  { id: 'cc_antigo', descricao: 'Histórico', ativo: false } // Inativo
];

// Flat list supporting up to 3 hierarchy levels
export const CATEGORIAS: Categoria[] = [
  // level 0 - Alimentação
  { id: 'cat_alimentacao', descricao: 'Alimentação', parentId: null, ativo: true },
  // level 1 sub_alimentação
  { id: 'cat_supermercado', descricao: 'Supermercado', parentId: 'cat_alimentacao', ativo: true },
  // level 2 sub_supermercado
  { id: 'cat_supermercado_goncalves', descricao: 'Supermercado Gonçalves', parentId: 'cat_supermercado', ativo: true },
  { id: 'cat_hortifruti', descricao: 'Hortifruti', parentId: 'cat_supermercado', ativo: true },
  // level 1 sub_restaurante
  { id: 'cat_restaurantes', descricao: 'Restaurantes', parentId: 'cat_alimentacao', ativo: true },
  { id: 'cat_fast_food', descricao: 'Fast Food', parentId: 'cat_restaurantes', ativo: true },

  // level 0 - Moradia
  { id: 'cat_moradia', descricao: 'Moradia', parentId: null, ativo: true },
  { id: 'cat_aluguel', descricao: 'Aluguel', parentId: 'cat_moradia', ativo: true },
  { id: 'cat_servicos', descricao: 'Serviços Recorrentes', parentId: 'cat_moradia', ativo: true },
  { id: 'cat_energia', descricao: 'Energia / Luz', parentId: 'cat_servicos', ativo: true },
  { id: 'cat_agua', descricao: 'Água', parentId: 'cat_servicos', ativo: true },
  { id: 'cat_internet', descricao: 'Internet Fibra', parentId: 'cat_servicos', ativo: true },

  // level 0 - Vestuário
  { id: 'cat_vestuario', descricao: 'Vestuário', parentId: null, ativo: true },
  { id: 'cat_roupas', descricao: 'Roupas', parentId: 'cat_vestuario', ativo: true },
  { id: 'cat_calcados', descricao: 'Calçados', parentId: 'cat_vestuario', ativo: true },

  // level 0 - Receitas
  { id: 'cat_receitas', descricao: 'Receitas', parentId: null, ativo: true },
  { id: 'cat_salario', descricao: 'Salário Fixo', parentId: 'cat_receitas', ativo: true },
  { id: 'cat_freelance', descricao: 'Projetos Freelance', parentId: 'cat_receitas', ativo: true },
  { id: 'cat_reembolsos', descricao: 'Reembolsos', parentId: 'cat_receitas', ativo: true },
];

/**
 * Calculador automático de faturas e extratos.
 * Determina os períodos de vigência e gera a base de dados de documentos.
 */
export function getDocumentoParaLancamento(
  dataStr: string,
  tipoOrigem: 'CONTA' | 'CARTAO',
  origemId: string,
  cartoes: Cartao[],
  contas: Conta[]
): { documentoId: string; docDescricao: string; docMes: number; docAno: number; docStatus: 'ABERTA' | 'FECHADA' } {
  const data = new Date(dataStr + 'T00:00:00');
  const ano = data.getFullYear();
  const mes = data.getMonth() + 1; // 1-indexed (Jan = 1, Dec = 12)
  const dia = data.getDate();

  if (tipoOrigem === 'CONTA') {
    // Extrato mensal fixo (1º dia ao último dia do próprio mês)
    const dataInicio = `${ano}-${String(mes).padStart(2, '0')}-01`;
    // Determinar último dia do mês
    const ultimoDia = new Date(ano, mes, 0).getDate();
    const dataFim = `${ano}-${String(mes).padStart(2, '0')}-${String(ultimoDia).padStart(2, '0')}`;
    
    const mesNomes = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    
    // Extratos de meses passados (ex: antes de Abril 2026) são fechado por padrão
    const isFechado = ano < 2026 || (ano === 2026 && mes < 3); // março 2026 está aberto na simulação

    return {
      documentoId: `extrato_${origemId}_${ano}_${mes}`,
      docDescricao: `Extrato ${mesNomes[mes - 1]}/${ano}`,
      docMes: mes,
      docAno: ano,
      docStatus: isFechado ? 'FECHADA' : 'ABERTA'
    };
  } else {
    // Cartão de Crédito - Regra dos Ciclos de Fatura
    const cartao = cartoes.find(c => c.id === origemId);
    const diaFechamento = cartao ? cartao.diaFechamento : 25;

    // Se o dia da compra é menor ou igual ao dia de fechamento do mês corrente,
    // a compra cai na fatura do mês subsequente (M+1). Se passar do fechamento, cai em M+2.
    // Exemplo: diaFechamento = 25.
    // Fatura de Março (referência 3) cobre de 26/01 a 25/02.
    // Fatura de Abril (referência 4) cobre de 26/02 a 25/03.
    // Fatura de Junho (referência 6) cobre de 26/04 a 25/05. 
    //
    // Portanto, para identificar a qual fatura de Referência (mês/ano) pertence:
    // Se a data da compra é entre 26 de (M-2) e 25 de (M-1), então ela pertence à fatura do mês M.
    // Vamos deduzir M a partir da data:
    // Se o dia do lançamento é maior que diaFechamento:
    //   Cai na fatura de lançamento do mês (M + 2).
    // Se o dia é menor ou igual do dia de fechamento:
    //   Cai na fatura de lançamento do mês (M + 1).

    let refMes = mes + 1;
    let refAno = ano;
    if (dia > diaFechamento) {
      refMes = mes + 2;
    }
    
    if (refMes > 12) {
      refMes -= 12;
      refAno += 1;
    }

    // Calcular as datas limites desta fatura de referência
    // Início: Fechamento + 1 do mês de referência - 2
    let inicioMes = refMes - 2;
    let inicioAno = refAno;
    if (inicioMes <= 0) {
      inicioMes += 12;
      inicioAno -= 1;
    }
    
    // Fim: Fechamento do mês de referência - 1
    let fimMes = refMes - 1;
    let fimAno = refAno;
    if (fimMes <= 0) {
      fimMes += 12;
      fimAno -= 1;
    }

    const dataInicio = `${inicioAno}-${String(inicioMes).padStart(2, '0')}-${String(diaFechamento + 1).padStart(2, '0')}`;
    const dataFim = `${fimAno}-${String(fimMes).padStart(2, '0')}-${String(diaFechamento).padStart(2, '0')}`;

    const mesNomes = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];

    // Fatura antes de Março/2026 considerada fechada para o exemplo
    const isFechado = refAno < 2026 || (refAno === 2026 && refMes < 3);

    return {
      documentoId: `fatura_${origemId}_${refAno}_${refMes}`,
      docDescricao: `Fatura ${mesNomes[refMes - 1]}/${refAno} (${diaFechamento})`,
      docMes: refMes,
      docAno: refAno,
      docStatus: isFechado ? 'FECHADA' : 'ABERTA'
    };
  }
}

// ------------------------------------------------------------------
// BASE SEED LANÇAMENTOS E ITENS
// ------------------------------------------------------------------

// Seed que representa o mês de Março/2026
export const INITIAL_LANCAMENTOS: Lancamento[] = [
  // 6.1 Compra à vista - Cartão de Crédito
  {
    id: 'lanc_1',
    data: '2026-03-02', // falls into April invoice for closing day 25, or March invoice for closing day 10. Let's let helper evaluate it!
    descricao: 'Compra no IG - Café Gourmet',
    tipo: 'DESPESA',
    valorTotal: 25.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_4', // falls into April (Mar 2th is between Feb 26 & Mar 25)
    status: 'PENDENTE',
    grupoId: null,
    tipoGrupo: null,
    parcelaNumero: null,
    totalParcelas: null,
    observacao: 'Compra à vista simples de café especial.',
    recorrente: false
  },
  // 6.2 Lançamento Parcelado (Riachuelo Blusa de Frio) - 7 meses.
  // Geração já rateada com o ajuste do centavo no primeiro lançamento.
  // Total: 75.00 dividido por 7 parcelas.
  // Parcela 1: 10.74, Parcelas 2 a 7: 10.71.
  {
    id: 'lanc_parcella_1',
    data: '2026-03-05',
    descricao: 'Riachuelo Blusa de Frio (1/7)',
    tipo: 'DESPESA',
    valorTotal: 10.74,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_4', // Mar 5th closes Mar 25 -> April invoice
    status: 'PENDENTE',
    grupoId: 'grupo_riachuelo_75',
    tipoGrupo: 'PARCELAMENTO',
    parcelaNumero: 1,
    totalParcelas: 7,
    observacao: 'Riachuelo Blusa Marcos - Centavo na 1ª parcela',
    recorrente: false
  },
  {
    id: 'lanc_parcella_2',
    data: '2026-04-05',
    descricao: 'Riachuelo Blusa de Frio (2/7)',
    tipo: 'DESPESA',
    valorTotal: 10.71,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_5',
    status: 'PENDENTE',
    grupoId: 'grupo_riachuelo_75',
    tipoGrupo: 'PARCELAMENTO',
    parcelaNumero: 2,
    totalParcelas: 7,
    observacao: 'Riachuelo Blusa Marcos',
    recorrente: false
  },
  {
    id: 'lanc_parcella_3',
    data: '2026-05-05',
    descricao: 'Riachuelo Blusa de Frio (3/7)',
    tipo: 'DESPESA',
    valorTotal: 10.71,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_6',
    status: 'PENDENTE',
    grupoId: 'grupo_riachuelo_75',
    tipoGrupo: 'PARCELAMENTO',
    parcelaNumero: 3,
    totalParcelas: 7,
    observacao: 'Riachuelo Blusa Marcos',
    recorrente: false
  },
  {
    id: 'lanc_parcella_4',
    data: '2026-06-05',
    descricao: 'Riachuelo Blusa de Frio (4/7)',
    tipo: 'DESPESA',
    valorTotal: 10.71,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_7',
    status: 'PENDENTE',
    grupoId: 'grupo_riachuelo_75',
    tipoGrupo: 'PARCELAMENTO',
    parcelaNumero: 4,
    totalParcelas: 7,
    observacao: 'Riachuelo Blusa Marcos',
    recorrente: false
  },
  {
    id: 'lanc_parcella_5',
    data: '2026-07-05',
    descricao: 'Riachuelo Blusa de Frio (5/7)',
    tipo: 'DESPESA',
    valorTotal: 10.71,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_8',
    status: 'PENDENTE',
    grupoId: 'grupo_riachuelo_75',
    tipoGrupo: 'PARCELAMENTO',
    parcelaNumero: 5,
    totalParcelas: 7,
    observacao: 'Riachuelo Blusa Marcos',
    recorrente: false
  },
  {
    id: 'lanc_parcella_6',
    data: '2026-08-05',
    descricao: 'Riachuelo Blusa de Frio (6/7)',
    tipo: 'DESPESA',
    valorTotal: 10.71,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_9',
    status: 'PENDENTE',
    grupoId: 'grupo_riachuelo_75',
    tipoGrupo: 'PARCELAMENTO',
    parcelaNumero: 6,
    totalParcelas: 7,
    observacao: 'Riachuelo Blusa Marcos',
    recorrente: false
  },
  {
    id: 'lanc_parcella_7',
    data: '2026-09-05',
    descricao: 'Riachuelo Blusa de Frio (7/7)',
    tipo: 'DESPESA',
    valorTotal: 10.71,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_10',
    status: 'PENDENTE',
    grupoId: 'grupo_riachuelo_75',
    tipoGrupo: 'PARCELAMENTO',
    parcelaNumero: 7,
    totalParcelas: 7,
    observacao: 'Riachuelo Blusa Marcos',
    recorrente: false
  },

  // 6.3 Replicar Parcelas (Exemplo 5 a 10 no valor de R$100,00 cada)
  {
    id: 'lanc_rep_5',
    data: '2026-03-10',
    descricao: 'Riachuelo Blusa de Frio (Replicado) (5/10)',
    tipo: 'DESPESA',
    valorTotal: 100.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_4',
    status: 'PENDENTE',
    grupoId: 'grupo_replicar_100',
    tipoGrupo: 'REPLICACAO',
    parcelaNumero: 5,
    totalParcelas: 10,
    observacao: 'Replicado inicial 5 final 10',
    recorrente: false
  },
  {
    id: 'lanc_rep_6',
    data: '2026-04-10',
    descricao: 'Riachuelo Blusa de Frio (Replicado) (6/10)',
    tipo: 'DESPESA',
    valorTotal: 100.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_5',
    status: 'PENDENTE',
    grupoId: 'grupo_replicar_100',
    tipoGrupo: 'REPLICACAO',
    parcelaNumero: 6,
    totalParcelas: 10,
    observacao: 'Replicado inicial 5 final 10',
    recorrente: false
  },
  {
    id: 'lanc_rep_7',
    data: '2026-05-10',
    descricao: 'Riachuelo Blusa de Frio (Replicado) (7/10)',
    tipo: 'DESPESA',
    valorTotal: 100.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_6',
    status: 'PENDENTE',
    grupoId: 'grupo_replicar_100',
    tipoGrupo: 'REPLICACAO',
    parcelaNumero: 7,
    totalParcelas: 10,
    observacao: 'Replicado inicial 5 final 10',
    recorrente: false
  },
  {
    id: 'lanc_rep_8',
    data: '2026-06-10',
    descricao: 'Riachuelo Blusa de Frio (Replicado) (8/10)',
    tipo: 'DESPESA',
    valorTotal: 100.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_7',
    status: 'PENDENTE',
    grupoId: 'grupo_replicar_100',
    tipoGrupo: 'REPLICACAO',
    parcelaNumero: 8,
    totalParcelas: 10,
    observacao: 'Replicado inicial 5 final 10',
    recorrente: false
  },
  {
    id: 'lanc_rep_9',
    data: '2026-07-10',
    descricao: 'Riachuelo Blusa de Frio (Replicado) (9/10)',
    tipo: 'DESPESA',
    valorTotal: 100.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_8',
    status: 'PENDENTE',
    grupoId: 'grupo_replicar_100',
    tipoGrupo: 'REPLICACAO',
    parcelaNumero: 9,
    totalParcelas: 10,
    observacao: 'Replicado inicial 5 final 10',
    recorrente: false
  },
  {
    id: 'lanc_rep_10',
    data: '2026-08-10',
    descricao: 'Riachuelo Blusa de Frio (Replicado) (10/10)',
    tipo: 'DESPESA',
    valorTotal: 100.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_itau',
    documentoId: 'fatura_cartao_itau_2026_9',
    status: 'PENDENTE',
    grupoId: 'grupo_replicar_100',
    tipoGrupo: 'REPLICACAO',
    parcelaNumero: 10,
    totalParcelas: 10,
    observacao: 'Replicado inicial 5 final 10',
    recorrente: false
  },

  // 6.4 Lançamento com RATEIO (Multi-categoria) - Supermercado Gonçalves
  // Total: 1000,00 reais. Rateio:
  // Categoria "Supermercado Gonçalves" -> R$ 700,00
  // Categoria "Hortifruti" -> R$ 300,00
  {
    id: 'lanc_rateio_1',
    data: '2026-03-12',
    descricao: 'Supermercado Gonçalves - Compras Mensais',
    tipo: 'DESPESA',
    valorTotal: 1000.00,
    tipoOrigem: 'CARTAO',
    origemId: 'cartao_nubank', // closing 10 -> dia 12 falls into April fatura
    documentoId: 'fatura_cartao_nubank_2026_4',
    status: 'PENDENTE',
    grupoId: null,
    tipoGrupo: null,
    parcelaNumero: null,
    totalParcelas: null,
    observacao: 'Compra rateada com 70% supermercado normal e 30% hortifruti saudável.',
    recorrente: false
  },

  // 6.5 Lançamento direto na Conta (Extrato automático)
  {
    id: 'lanc_salario',
    data: '2026-03-01',
    descricao: 'Salário Mensal Principal',
    tipo: 'RECEITA',
    valorTotal: 6500.00,
    tipoOrigem: 'CONTA',
    origemId: 'conta_itau',
    documentoId: 'extrato_conta_itau_2026_3', // falls directly into March Statement
    status: 'CONSOLIDADO',
    grupoId: null,
    tipoGrupo: null,
    parcelaNumero: null,
    totalParcelas: null,
    observacao: 'Trabalho integral mensal.',
    recorrente: true
  },
  {
    id: 'lanc_internet',
    data: '2026-03-15',
    descricao: 'Internet Fibra Óptica Residencial',
    tipo: 'DESPESA',
    valorTotal: 120.00,
    tipoOrigem: 'CONTA',
    origemId: 'conta_nubank',
    documentoId: 'extrato_conta_nubank_2026_3',
    status: 'CONSOLIDADO',
    grupoId: null,
    tipoGrupo: null,
    parcelaNumero: null,
    totalParcelas: null,
    observacao: 'Débito automático no Nubank.',
    recorrente: true
  },
  {
    id: 'lanc_luz',
    data: '2026-03-18',
    descricao: 'Conta de Energia Elétrica Neoenergia',
    tipo: 'DESPESA',
    valorTotal: 185.30,
    tipoOrigem: 'CONTA',
    origemId: 'conta_itau',
    documentoId: 'extrato_conta_itau_2026_3',
    status: 'PENDENTE',
    grupoId: null,
    tipoGrupo: null,
    parcelaNumero: null,
    totalParcelas: null,
    observacao: '',
    recorrente: false
  }
];

export const INITIAL_ITENS: ItemLancamento[] = [
  // Item 6.1 - Compra no IG
  {
    id: 'item_1',
    lancamentoId: 'lanc_1',
    categoriaId: 'cat_fast_food',
    centroCustoId: 'cc_geral',
    valor: 25.00
  },

  // Itens 6.2 - Cartão parcelado blusa (cada lançamento tem pelo menos 1 item)
  { id: 'item_p1', lancamentoId: 'lanc_parcella_1', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 10.74 },
  { id: 'item_p2', lancamentoId: 'lanc_parcella_2', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 10.71 },
  { id: 'item_p3', lancamentoId: 'lanc_parcella_3', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 10.71 },
  { id: 'item_p4', lancamentoId: 'lanc_parcella_4', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 10.71 },
  { id: 'item_p5', lancamentoId: 'lanc_parcella_5', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 10.71 },
  { id: 'item_p6', lancamentoId: 'lanc_parcella_6', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 10.71 },
  { id: 'item_p7', lancamentoId: 'lanc_parcella_7', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 10.71 },

  // Itens 6.3 - Replicáveis
  { id: 'item_r5', lancamentoId: 'lanc_rep_5', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 100.00 },
  { id: 'item_r6', lancamentoId: 'lanc_rep_6', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 100.00 },
  { id: 'item_r7', lancamentoId: 'lanc_rep_7', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 100.00 },
  { id: 'item_r8', lancamentoId: 'lanc_rep_8', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 100.00 },
  { id: 'item_r9', lancamentoId: 'lanc_rep_9', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 100.00 },
  { id: 'item_r10', lancamentoId: 'lanc_rep_10', categoriaId: 'cat_roupas', centroCustoId: 'cc_marcos', valor: 100.00 },

  // Itens 6.4 - RATEADO (Multi-category)
  // Supermercado Gonçalves -> R$ 700,00
  // Hortifruti -> R$ 300,00
  {
    id: 'item_rateio_a',
    lancamentoId: 'lanc_rateio_1',
    categoriaId: 'cat_supermercado_goncalves',
    centroCustoId: 'cc_geral',
    valor: 700.00
  },
  {
    id: 'item_rateio_b',
    lancamentoId: 'lanc_rateio_1',
    categoriaId: 'cat_hortifruti',
    centroCustoId: 'cc_flavia',
    valor: 300.00
  },

  // Itens 6.5 - Contas correntes
  {
    id: 'item_salario',
    lancamentoId: 'lanc_salario',
    categoriaId: 'cat_salario',
    centroCustoId: 'cc_geral',
    valor: 6500.00
  },
  {
    id: 'item_internet',
    lancamentoId: 'lanc_internet',
    categoriaId: 'cat_internet',
    centroCustoId: 'cc_geral',
    valor: 120.00
  },
  {
    id: 'item_luz',
    lancamentoId: 'lanc_luz',
    categoriaId: 'cat_energia',
    centroCustoId: 'cc_geral',
    valor: 185.30
  }
];
