/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Conta, 
  Cartao, 
  CentroCusto, 
  Categoria, 
  Lancamento, 
  ItemLancamento, 
  LancamentoComDetalhes, 
  TipoOrigem,
  StatusLancamento
} from './types';
import { 
  BANCOS, 
  CONTAS, 
  CARTOES, 
  CENTROS_CUSTO, 
  CATEGORIAS, 
  INITIAL_LANCAMENTOS, 
  INITIAL_ITENS,
  getDocumentoParaLancamento
} from './data/mockData';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import TransactionList from './components/TransactionList';
import TransactionDialog from './components/TransactionDialog';
import FlutterCodeViewer from './components/FlutterCodeViewer';
import FirebasePreview from './components/FirebasePreview';
import FinancialReports from './components/FinancialReports';
import { Layout, FileCode, Database, BarChart3, Info, AlertTriangle } from 'lucide-react';

export default function App() {
  // Master databases loaded into React state
  const [contas, setContas] = useState<Conta[]>(CONTAS);
  const [cartoes, setCartoes] = useState<Cartao[]>(CARTOES);
  const [centrosCusto] = useState<CentroCusto[]>(CENTROS_CUSTO);
  const [categorias, setCategorias] = useState<Categoria[]>(CATEGORIAS);
  
  const [lancamentos, setLancamentos] = useState<Lancamento[]>(INITIAL_LANCAMENTOS);
  const [itens, setItens] = useState<ItemLancamento[]>(INITIAL_ITENS);

  // Layout Tab selections
  const [activeLayoutTab, setActiveLayoutTab] = useState<'LEDGER' | 'REPORTS' | 'FIREBASE' | 'FLUTTER'>('LEDGER');

  // Interactive filters
  const [currentMonth, setCurrentMonth] = useState<number>(3); // Default Mar/2026
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [checkedContaIds, setCheckedContaIds] = useState<string[]>([]);
  const [checkedCartaoIds, setCheckedCartaoIds] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const handleToggleConta = (id: string | 'CLEAR_ALL') => {
    if (id === 'CLEAR_ALL') {
      setCheckedContaIds([]);
      return;
    }
    setCheckedContaIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleToggleCartao = (id: string | 'CLEAR_ALL') => {
    if (id === 'CLEAR_ALL') {
      setCheckedCartaoIds([]);
      return;
    }
    setCheckedCartaoIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleClearAllOrigens = () => {
    setCheckedContaIds([]);
    setCheckedCartaoIds([]);
  };
  const [checkedCategoryIds, setCheckedCategoryIds] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<'TODAS' | 'PENDENTES' | 'CONSOLIDADOS'>('TODAS');

  // Row selection checkboxes state (for batch processing)
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Dialog controllers
  const [isDialogModelOpen, setIsDialogModelOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<LancamentoComDetalhes | null>(null);

  // Recursive Category children getter to support cascading selection checks
  const getCategoryChildrenIds = (catId: string): string[] => {
    const list: string[] = [catId];
    const gather = (parId: string) => {
      categorias.forEach(cat => {
        if (cat.parentId === parId) {
          list.push(cat.id);
          gather(cat.id);
        }
      });
    };
    gather(catId);
    return list;
  };

  const handleToggleCategoryAndChildren = (catId: string) => {
    if (catId === 'CLEAR_ALL') {
      setCheckedCategoryIds([]);
      return;
    }

    const linkedIds = getCategoryChildrenIds(catId);
    const someChecked = linkedIds.some(id => checkedCategoryIds.includes(id));

    if (someChecked) {
      // Uncheck all linked cascade levels
      setCheckedCategoryIds(prev => prev.filter(id => !linkedIds.includes(id)));
    } else {
      // Check all linked cascade levels
      setCheckedCategoryIds(prev => Array.from(new Set([...prev, ...linkedIds])));
    }
  };

  // ------------------------------------------------------------------
  // INJECT NAMES AND META RELATIONS PRIOR TO CORRELATION RENDERING
  // ------------------------------------------------------------------
  const enrichedTransactions = useMemo((): LancamentoComDetalhes[] => {
    return lancamentos.map(lanc => {
      // Match child items rateio
      const matchingItens = itens.filter(it => it.lancamentoId === lanc.id);
      
      // Compute Origin tag
      let origemNome = 'Outros';
      if (lanc.tipoOrigem === 'CONTA') {
        origemNome = contas.find(c => c.id === lanc.origemId)?.descricao || 'Conta';
      } else {
        origemNome = cartoes.find(ca => ca.id === lanc.origemId)?.descricao || 'Cartão';
      }

      // Compute Documento descriptor
      const docDetails = getDocumentoParaLancamento(lanc.data, lanc.tipoOrigem, lanc.origemId, cartoes, contas);

      return {
        ...lanc,
        itens: matchingItens,
        origemNome,
        documentoDesc: docDetails.docDescricao
      };
    });
  }, [lancamentos, itens, contas, cartoes]);

  // ------------------------------------------------------------------
  // DYNAMIC FILTERS APPLICATION
  // ------------------------------------------------------------------
  const filteredTransactions = useMemo((): LancamentoComDetalhes[] => {
    return enrichedTransactions.filter(t => {
      // 1. Month/Year filter based strictly on evaluated reference document period
      const docMeta = getDocumentoParaLancamento(t.data, t.tipoOrigem, t.origemId, cartoes, contas);
      if (docMeta.docMes !== currentMonth || docMeta.docAno !== currentYear) {
        return false;
      }

      // 2. Origin (Account/Card) selection (Multi-select)
      const hasOriginFilter = checkedContaIds.length > 0 || checkedCartaoIds.length > 0;
      if (hasOriginFilter) {
        const matchConta = t.tipoOrigem === 'CONTA' && checkedContaIds.includes(t.origemId);
        const matchCartao = t.tipoOrigem === 'CARTAO' && checkedCartaoIds.includes(t.origemId);
        if (!matchConta && !matchCartao) {
          return false;
        }
      }

      // 3. Category Tree cascades (Checks if any matching rateio item matches checked filters)
      if (checkedCategoryIds.length > 0) {
        const matchesCategory = t.itens.some(it => checkedCategoryIds.includes(it.categoriaId));
        if (!matchesCategory) return false;
      }

      // 4. Status criteria
      if (statusFilter === 'PENDENTES' && t.status !== 'PENDENTE') return false;
      if (statusFilter === 'CONSOLIDADOS' && t.status !== 'CONSOLIDADO') return false;

      // 5. Search text queries (covers description, values, and notes)
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesDesc = t.descricao.toLowerCase().includes(query);
        const matchesObs = t.observacao?.toLowerCase().includes(query) || false;
        const matchesValue = t.valorTotal.toString().includes(query);
        const matchesCategoryLabels = t.itens.some(it => {
          const desc = categorias.find(c => c.id === it.categoriaId)?.descricao || '';
          return desc.toLowerCase().includes(query);
        });

        if (!matchesDesc && !matchesObs && !matchesValue && !matchesCategoryLabels) {
          return false;
        }
      }

      return true;
    });
  }, [enrichedTransactions, currentMonth, currentYear, checkedContaIds, checkedCartaoIds, checkedCategoryIds, statusFilter, searchQuery, categorias, cartoes, contas]);

  // ------------------------------------------------------------------
  // INDIVIDUAL ROW SELECTION BINDINGS
  // ------------------------------------------------------------------
  const handleToggleSelectId = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllForToday = (date: string, ids: string[]) => {
    const allSelected = ids.every(id => selectedIds.includes(id));
    if (allSelected) {
      setSelectedIds(prev => prev.filter(id => !ids.includes(id)));
    } else {
      setSelectedIds(prev => Array.from(new Set([...prev, ...ids])));
    }
  };

  // ------------------------------------------------------------------
  // BATCH OPERATIONS IMPLEMENTATIONS
  // ------------------------------------------------------------------
  const handleBatchConsolidate = () => {
    setLancamentos(prev => prev.map(l => 
      selectedIds.includes(l.id) ? { ...l, status: 'CONSOLIDADO' } : l
    ));
    setSelectedIds([]);
  };

  const handleBatchDelete = () => {
    if (window.confirm(`Tem certeza que gostaria de excluir os ${selectedIds.length} lançamentos selecionados?`)) {
      setLancamentos(prev => prev.filter(l => !selectedIds.includes(l.id)));
      setItens(prev => prev.filter(it => !selectedIds.includes(it.lancamentoId)));
      setSelectedIds([]);
    }
  };

  const handleBatchChangeCategory = (catId: string) => {
    setItens(prev => prev.map(it => 
      selectedIds.includes(it.lancamentoId) ? { ...it, categoriaId: catId } : it
    ));
    setSelectedIds([]);
  };

  // ------------------------------------------------------------------
  // CRUD TRANSACTION EVENTS (COULD COMMUNICATE WITH FIREBASE API)
  // ------------------------------------------------------------------
  const handleOpenAddDialog = () => {
    setEditingTransaction(null);
    setIsDialogModelOpen(true);
  };

  const handleEditTransactionClick = (transaction: LancamentoComDetalhes) => {
    setEditingTransaction(transaction);
    setIsDialogModelOpen(true);
  };

  // Save workflow (Handles Case 6.1, Case 6.2, Case 6.3, Case 6.4 and Case 6.5)
  const handleSaveTransaction = ({ lancamento, itens: rateioItens, applyOption, isDividido, numParcelas, isReplicado, parcelaInicial, parcelaFinal }: any) => {
    const isEditing = !!lancamento.id;

    if (isEditing) {
      // ------------------------------------------------------------------
      // EDIT MODE (WITH ROLL-FORWARD GROUP LOGIC - Case 4.5 / 6.2 / 6.3)
      // ------------------------------------------------------------------
      const targetId = lancamento.id!;
      const current = lancamentos.find(l => l.id === targetId)!;

      if (current.grupoId && applyOption && applyOption !== 'ONLY_THIS') {
        // Group modification: filter related siblings
        let siblings = lancamentos.filter(l => l.grupoId === current.grupoId);
        
        if (applyOption === 'FROM_THIS_ONWARD') {
          siblings = siblings.filter(l => (l.parcelaNumero || 0) >= (current.parcelaNumero || 0));
        }

        const siblingIds = siblings.map(s => s.id);

        // Edit parent Launch records
        setLancamentos(prev => prev.map(l => {
          if (siblingIds.includes(l.id)) {
            // Keep numerical indices and offsets isolated but copy primary descriptions, values and bank accounts!
            return {
              ...l,
              descricao: `${lancamento.descricao.split(' (')[0]} (${l.parcelaNumero}/${l.totalParcelas})`,
              tipo: lancamento.tipo,
              valorTotal: lancamento.valorTotal, // keep value consistent
              tipoOrigem: lancamento.tipoOrigem,
              origemId: lancamento.origemId,
              observacao: lancamento.observacao,
              status: lancamento.status,
              recorrente: lancamento.recorrente
            };
          }
          return l;
        }));

        // Edit Rateios child Items
        setItens(prev => prev.map(it => {
          if (siblingIds.includes(it.lancamentoId)) {
            const matchRateioRow = rateioItens[0]; // simplistic group roll forward for single-item categories
            return {
              ...it,
              categoriaId: matchRateioRow ? matchRateioRow.categoriaId : it.categoriaId,
              centroCustoId: matchRateioRow ? matchRateioRow.centroCustoId : it.centroCustoId,
              valor: lancamento.valorTotal // matches consolidated price
            };
          }
          return it;
        }));
      } else {
        // Simple Single Localized Edit
        setLancamentos(prev => prev.map(l => l.id === targetId ? { ...l, ...lancamento } as Lancamento : l));
        
        // Remove prior items first
        setItens(prev => {
          const filtered = prev.filter(it => it.lancamentoId !== targetId);
          // Insert new ones
          const fresh = rateioItens.map((it: any, index: number) => ({
            id: `item_${targetId}_${index}`,
            lancamentoId: targetId,
            categoriaId: it.categoriaId,
            centroCustoId: it.centroCustoId,
            valor: it.valor
          }));
          return [...filtered, ...fresh];
        });
      }
    } else {
      // ------------------------------------------------------------------
      // CREATION MODE (Handles splits, installments, replications)
      // ------------------------------------------------------------------
      const baseId = `lanc_${Date.now()}`;

      if (isDividido && numParcelas > 1) {
        // --- 4.2 COMPRA PARCELADA WITH PENNY ADJUSTMENT (Case 6.2) ---
        const totalAmount = lancamento.valorTotal;
        const baseAmount = Math.floor((totalAmount / numParcelas) * 100) / 100;
        const pennies = Number((totalAmount - (baseAmount * numParcelas)).toFixed(2));
        const grupoId = `grupo_div_${baseId}`;

        const newLancs: Lancamento[] = [];
        const newItens: ItemLancamento[] = [];

        for (let i = 1; i <= numParcelas; i++) {
          const installmentVal = i === 1 ? Number((baseAmount + pennies).toFixed(2)) : baseAmount;
          const instId = `${baseId}_p_${i}`;
          
          // Calculate installment month offsets
          const purchaseDate = new Date(lancamento.data + 'T00:00:00');
          purchaseDate.setMonth(purchaseDate.getMonth() + (i - 1));
          
          // Format back to YYYY-MM-DD
          const year = purchaseDate.getFullYear();
          const month = String(purchaseDate.getMonth() + 1).padStart(2, '0');
          const day = String(purchaseDate.getDate()).padStart(2, '0');
          const dateStr = `${year}-${month}-${day}`;

          const docMeta = getDocumentoParaLancamento(dateStr, lancamento.tipoOrigem, lancamento.origemId, cartoes, contas);

          newLancs.push({
            ...lancamento,
            id: instId,
            data: dateStr,
            descricao: `${lancamento.descricao} (${i}/${numParcelas})`,
            valorTotal: installmentVal,
            documentoId: docMeta.documentoId,
            grupoId,
            tipoGrupo: 'PARCELAMENTO',
            parcelaNumero: i,
            totalParcelas: numParcelas
          } as Lancamento);

          // Add corresponding sub item
          newItens.push({
            id: `item_${instId}_0`,
            lancamentoId: instId,
            categoriaId: rateioItens[0]?.categoriaId || 'cat_supermercado_goncalves',
            centroCustoId: rateioItens[0]?.centroCustoId || 'cc_geral',
            valor: installmentVal
          });
        }

        setLancamentos(prev => [...prev, ...newLancs]);
        setItens(prev => [...prev, ...newItens]);

      } else if (isReplicado && parcelaFinal >= parcelaInicial) {
        // --- 4.3 REPLICAR PARCELAS (Case 6.3) ---
        const totalCount = (parcelaFinal - parcelaInicial) + 1;
        const grupoId = `grupo_rep_${baseId}`;

        const newLancs: Lancamento[] = [];
        const newItens: ItemLancamento[] = [];

        for (let idx = 0; idx < totalCount; idx++) {
          const currentPartNum = parcelaInicial + idx;
          const instId = `${baseId}_r_${currentPartNum}`;

          // Offset dates month by month
          const purchaseDate = new Date(lancamento.data + 'T00:00:00');
          purchaseDate.setMonth(purchaseDate.getMonth() + idx);
          
          const year = purchaseDate.getFullYear();
          const month = String(purchaseDate.getMonth() + 1).padStart(2, '0');
          const day = String(purchaseDate.getDate()).padStart(2, '0');
          const dateStr = `${year}-${month}-${day}`;

          const docMeta = getDocumentoParaLancamento(dateStr, lancamento.tipoOrigem, lancamento.origemId, cartoes, contas);

          newLancs.push({
            ...lancamento,
            id: instId,
            data: dateStr,
            descricao: `${lancamento.descricao} (${currentPartNum}/${parcelaFinal})`,
            valorTotal: lancamento.valorTotal, // integral complete amount
            documentoId: docMeta.documentoId,
            grupoId,
            tipoGrupo: 'REPLICACAO',
            parcelaNumero: currentPartNum,
            totalParcelas: parcelaFinal
          } as Lancamento);

          newItens.push({
            id: `item_${instId}_0`,
            lancamentoId: instId,
            categoriaId: rateioItens[0]?.categoriaId || 'cat_supermercado_goncalves',
            centroCustoId: rateioItens[0]?.centroCustoId || 'cc_geral',
            valor: lancamento.valorTotal
          });
        }

        setLancamentos(prev => [...prev, ...newLancs]);
        setItens(prev => [...prev, ...newItens]);

      } else {
        // --- 4.1 COMPRA SIMPLES (VISTA) OR 4.4 COMPRA COM RATEIO ---
        // Auto assign billing document cycles (Fatura or Extrato)
        const docMeta = getDocumentoParaLancamento(lancamento.data, lancamento.tipoOrigem, lancamento.origemId, cartoes, contas);
        
        const freshLanc: Lancamento = {
          ...lancamento,
          id: baseId,
          documentoId: docMeta.documentoId,
          grupoId: null,
          tipoGrupo: null,
          parcelaNumero: null,
          totalParcelas: null
        } as Lancamento;

        const freshItens: ItemLancamento[] = rateioItens.map((it: any, index: number) => ({
          id: `item_${baseId}_${index}`,
          lancamentoId: baseId,
          categoriaId: it.categoriaId,
          centroCustoId: it.centroCustoId,
          valor: it.valor
        }));

        setLancamentos(prev => [...prev, freshLanc]);
        setItens(prev => [...prev, ...freshItens]);
      }
    }

    setIsDialogModelOpen(false);
    setEditingTransaction(null);
  };

  // Compute stats summaries of active viewed segment
  const activeMonthLabel = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ][currentMonth - 1];

  return (
    <div className="w-screen h-screen flex flex-col bg-slate-50 text-slate-800 font-sans antialiased overflow-hidden select-none">
      
      {/* Top Application Layout Switcher bar */}
      <div className="bg-slate-900 border-b border-slate-950 px-6 py-2.5 flex items-center justify-between text-white flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-[10px] uppercase font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded px-2 py-0.5 tracking-wider font-extrabold shadow-sm">
            ZZuna Workspace
          </span>
          <span className="text-slate-500 text-xs font-mono">📅 Simulação: 05/Mar/2026</span>
        </div>

        {/* Views toggler */}
        <div className="flex gap-1.5 p-0.5 bg-slate-950 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveLayoutTab('LEDGER')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-extrabold rounded-md transition-all cursor-pointer ${
              activeLayoutTab === 'LEDGER' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layout size={12} />
            ZZuna Ledger
          </button>
          <button
            onClick={() => setActiveLayoutTab('REPORTS')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-extrabold rounded-md transition-all cursor-pointer ${
              activeLayoutTab === 'REPORTS' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart3 size={12} />
            Relatórios
          </button>
          <button
            onClick={() => setActiveLayoutTab('FIREBASE')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-extrabold rounded-md transition-all cursor-pointer ${
              activeLayoutTab === 'FIREBASE' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database size={12} />
            Firebase DB
          </button>
          <button
            onClick={() => setActiveLayoutTab('FLUTTER')}
            className={`flex items-center gap-1 px-3 py-1 text-[11px] font-extrabold rounded-md transition-all cursor-pointer ${
              activeLayoutTab === 'FLUTTER' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode size={12} />
            Exportar Flutter
          </button>
        </div>
      </div>

      {/* Main Core Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Fixed (Contains controls) */}
        <Sidebar
          contas={contas}
          cartoes={cartoes}
          categorias={categorias}
          checkedContaIds={checkedContaIds}
          checkedCartaoIds={checkedCartaoIds}
          onToggleConta={handleToggleConta}
          onToggleCartao={handleToggleCartao}
          onClearAllOrigens={handleClearAllOrigens}
          checkedCategoryIds={checkedCategoryIds}
          onToggleCategoryAndChildren={handleToggleCategoryAndChildren}
        />

        {/* Right workspace */}
        <div className="flex-1 flex flex-col overflow-hidden">
          
          {/* Main simulation view panel content */}
          {activeLayoutTab === 'LEDGER' && (
            <>
              {/* Dynamic Action Topbar */}
              <Topbar
                currentMonth={currentMonth}
                currentYear={currentYear}
                onMonthYearChange={(m, y) => {
                  setCurrentMonth(m);
                  setCurrentYear(y);
                  setSelectedIds([]);
                }}
                statusFilter={statusFilter}
                onStatusFilterChange={(f) => {
                  setStatusFilter(f);
                  setSelectedIds([]);
                }}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                selectedCount={selectedIds.length}
                onBatchConsolidate={handleBatchConsolidate}
                onBatchDelete={handleBatchDelete}
                onBatchChangeCategory={handleBatchChangeCategory}
                categoriasList={categorias}
                onOpenAddDialog={handleOpenAddDialog}
                onOpenExportView={() => setActiveLayoutTab('FLUTTER')}
              />

              {/* Status information notice bar */}
              <div className="bg-emerald-500/5 px-6 py-2.5 border-b border-slate-200 flex flex-wrap gap-4 items-center text-[11px] text-slate-500 justify-between select-none">
                <div className="flex items-center gap-1.5 font-medium">
                  <Info size={13} className="text-emerald-600" />
                  <span>Exibindo competência de: <strong className="text-slate-700 font-bold underline">{activeMonthLabel}/{currentYear}</strong></span>
                  {(checkedContaIds.length > 0 || checkedCartaoIds.length > 0) && (
                    <span className="bg-slate-100 text-slate-700 px-1 rounded font-extrabold scale-95 origin-left">
                      Filtro origem ativo ({checkedContaIds.length + checkedCartaoIds.length})
                    </span>
                  )}
                  {checkedCategoryIds.length > 0 && (
                    <span className="bg-teal-50 text-teal-700 px-1 rounded font-extrabold scale-95 origin-left">
                      Filtrando por {checkedCategoryIds.length} categorias
                    </span>
                  )}
                </div>

                <span className="font-semibold text-slate-400">
                  Mostrando {filteredTransactions.length} lançamentos encontrados
                </span>
              </div>

              {/* Central Dynamic Ledger List */}
              <TransactionList
                transactions={filteredTransactions}
                selectedIds={selectedIds}
                onToggleSelect={handleToggleSelectId}
                onSelectAllForToday={handleSelectAllForToday}
                onEditTransaction={handleEditTransactionClick}
                categorias={categorias}
                contas={contas}
                cartoes={cartoes}
                centrosCusto={centrosCusto}
              />
            </>
          )}

          {activeLayoutTab === 'REPORTS' && (
            <div className="flex-1 overflow-y-auto p-8">
              <FinancialReports
                transactions={filteredTransactions}
                categorias={categorias}
                centrosCusto={centrosCusto}
              />
            </div>
          )}

          {activeLayoutTab === 'FIREBASE' && (
            <div className="flex-1 overflow-y-auto p-8">
              <FirebasePreview
                lancamentos={lancamentos}
                contas={contas}
                cartoes={cartoes}
                centrosCusto={centrosCusto}
                categorias={categorias}
              />
            </div>
          )}

          {activeLayoutTab === 'FLUTTER' && (
            <div className="flex-1 overflow-y-auto p-8">
              <FlutterCodeViewer />
            </div>
          )}
        </div>
      </div>

      {/* Unified High-Fidelity Transaction Modal Form */}
      <TransactionDialog
        isOpen={isDialogModelOpen}
        onClose={() => {
          setIsDialogModelOpen(false);
          setEditingTransaction(null);
        }}
        onSave={handleSaveTransaction}
        editingTransaction={editingTransaction}
        categorias={categorias}
        contas={contas}
        cartoes={cartoes}
        centrosCusto={centrosCusto}
      />
    </div>
  );
}
