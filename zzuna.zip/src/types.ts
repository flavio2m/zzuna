/**
 * Types modeling the ZZuna financial platform domain model.
 */

export type TipoLancamento = 'RECEITA' | 'DESPESA' | 'TRANSFERENCIA';
export type TipoOrigem = 'CONTA' | 'CARTAO';
export type StatusLancamento = 'PENDENTE' | 'CONSOLIDADO';
export type TipoGrupo = 'PARCELAMENTO' | 'TRANSFERENCIA' | 'REPLICACAO' | null;
export type TipoDocumento = 'FATURA' | 'EXTRATO';
export type StatusDocumento = 'ABERTA' | 'FECHADA';

export interface Banco {
  id: string;
  descricao: string;
  sigla: string;
  iconeUrl: string;
  ativo: boolean;
}

export interface Conta {
  id: string;
  descricao: string;
  bancoId: string;
  saldo: number;
  ativo: boolean;
}

export interface Cartao {
  id: string;
  descricao: string;
  bancoId: string;
  diaFechamento: number;
  saldo: number;
  ativo: boolean;
}

export interface Documento {
  id: string;
  tipo: TipoDocumento;
  origemId: string; // contaId ou cartaoId
  dataInicio: string; // YYYY-MM-DD
  dataFim: string; // YYYY-MM-DD
  mesReferencia: number; // 1 = Janeiro, 2 = Fevereiro, etc.
  anoReferencia: number;
  status: StatusDocumento;
}

export interface Categoria {
  id: string;
  descricao: string;
  parentId: string | null; // Niveis: Raiz -> Sub1 -> Sub2 (Até 3 níveis)
  ativo: boolean;
}

export interface CentroCusto {
  id: string;
  descricao: string;
  ativo: boolean;
}

export interface Lancamento {
  id: string;
  data: string; // YYYY-MM-DD
  descricao: string;
  tipo: TipoLancamento;
  valorTotal: number;
  tipoOrigem: TipoOrigem;
  origemId: string; // contaId ou cartaoId
  documentoId: string; // Fatura ou Extrato correspondente
  status: StatusLancamento;
  grupoId: string | null; // Une parcelamentos, replicações ou transferências
  tipoGrupo: TipoGrupo;
  parcelaNumero: number | null;
  totalParcelas: number | null;
  observacao: string;
  recorrente: boolean;
}

export interface ItemLancamento {
  id: string;
  lancamentoId: string;
  categoriaId: string;
  centroCustoId: string;
  valor: number;
}

// Relational item combined with its details for list presentation
export interface LancamentoComDetalhes extends Lancamento {
  itens: ItemLancamento[];
  origemNome: string;
  documentoDesc: string;
}
